---
name: Pop Kinetic Ticketing
colors:
  surface: '#fbf9f6'
  surface-dim: '#dbdad7'
  surface-bright: '#fbf9f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f0'
  surface-container: '#efeeeb'
  surface-container-high: '#eae8e5'
  surface-container-highest: '#e4e2df'
  on-surface: '#1b1c1a'
  on-surface-variant: '#434655'
  inverse-surface: '#30312f'
  inverse-on-surface: '#f2f0ed'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#b90538'
  on-secondary: '#ffffff'
  secondary-container: '#dc2c4f'
  on-secondary-container: '#fffbff'
  tertiary: '#735c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#cea700'
  on-tertiary-container: '#4e3d00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#ffdadb'
  secondary-fixed-dim: '#ffb2b7'
  on-secondary-fixed: '#40000d'
  on-secondary-fixed-variant: '#92002a'
  tertiary-fixed: '#ffe083'
  tertiary-fixed-dim: '#eec200'
  on-tertiary-fixed: '#231b00'
  on-tertiary-fixed-variant: '#574500'
  background: '#fbf9f6'
  on-background: '#1b1c1a'
  surface-variant: '#e4e2df'
typography:
  headline-xl:
    fontFamily: Bricolage Grotesque
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 52px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Bricolage Grotesque
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Bricolage Grotesque
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Bricolage Grotesque
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Bricolage Grotesque
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
  title-lg:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
  title-md:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system translates the explosive visual energy of mid-century Pop Art (Roy Lichtenstein, Andy Warhol, vintage silkscreen printing) into a sharp, responsive mobile ticketing application. It strips away sterile corporate minimalism in favor of high-energy tactile interactions, graphic comic framing, and saturated printing-press primaries.

### Brand Personality & Core Values
- **Electric & Unapologetic:** Interfaces demand attention using comic-strip black lines, Ben-Day dot flourishes, and vibrant primary inks.
- **Physical & Kinetic:** Taps and presses physically compress into flat offset drop shadows like physical buttons or punch tickets.
- **Precision Ticketing:** Despite loud styling, transactional details (dates, seat rows, QR scans, barcodes) remain razor-sharp, legibly grounded in clean monospaced and grotesque typography.

### Target Audience
Concert-goers, festival-seekers, gallery visitors, and indie event attendees who desire excitement in the ticket-buying flow rather than friction-filled utility.

## Colors

The palette simulates comic book offset printing on uncoated newsprint stock. Surfaces favor a warm, tactile cream base rather than sterile digital whites, creating immediate contrast against pure jet-black graphic inks.

### Palette Roles
- **Canvas Base (`#FAF8F5`):** The primary paper stock. Warm, clean ivory minimizing glare while setting a tactile backdrop.
- **Electric Cobalt (`#2563EB`):** Primary action color. Lichtenstein blue used for main CTAs, active states, and verified badge treatments.
- **Pop Vermilion / Hot Magenta (`#F43F5E`):** Secondary accent. High-urgency alert banners, heart/save toggles, countdown timers, and "Sold Out" flags.
- **Canary Yellow (`#FACC15`):** Tertiary punch color. Spotlights VIP upgrades, starburst burst badges, and promotional ticker tapes.
- **Ink Black (`#0A0A0A`):** Structural borders, hard shadow projections, and high-legibility typographic headers.
- **Pure Canvas Tint (`#FFFDF0`):** Secondary container surface for elevated cards and modal popovers to stand distinct against the base `#FAF8F5`.

## Typography

The typographic hierarchy balances expressive graphic-novel punch with technical clarity:

- **Bricolage Grotesque (Headlines):** Supplies vintage cartoon-strip flare with exaggerated letter shapes, wide curves, and ink-trap nuances. Used in uppercase or sentence case with tight letter-spacing for event names, major calls to action, and promotional banners.
- **Space Grotesk (Body, Metadata & Labels):** Acts as the geometric anchor. Maintains high readability for showtimes, venue directions, ticket tiers, and pricing tiers without sacrificing the retro-modern aesthetic.

All labels (`label-lg`, `label-md`, `label-sm`) default to uppercase tracking for a punchy, mechanical stamp impression.

## Layout & Spacing

Layout adheres to a clean, rhythmic grid enclosed by solid structural frames.

### Grid & Breakpoints
- **Mobile (< 768px):** 4-column fluid layout with `1rem` margins and `1rem` gutters. Elements snap edge-to-edge or sit inside bordered panel cards.
- **Desktop / Tablet (>= 768px):** Max container width of `1200px` within an 8-column (tablet) or 12-column (desktop) grid, using `2.5rem` outer margins and `1.5rem` gutters.

### Rhythmic Rules
- **Comic Panel Framing:** Cards, modules, and modals use structural containment. Avoid borderless floating components.
- **Tension & Density:** Content groups sit compactly (`space-sm` to `space-md`), creating a deliberate visual weight similar to comic panels.

## Elevation & Depth

This system avoids Gaussian blur and ambient diffused drop-shadows. Depth is purely graphic, hard-edged, and tactile:

- **Hard Offset Cast Shadows:** Elevation is rendered through solid `#0A0A0A` drop shadows with 0px blur. 
  - Resting Card / Container: `shadow-[4px_4px_0px_#0A0A0A]`
  - Interactive Button / Interactive Chip: `shadow-[3px_3px_0px_#0A0A0A]`
  - Modal / Sheet Overlays: `shadow-[8px_8px_0px_#0A0A0A]`
- **Active State Depress:** On `:active` or click/press interactions, interactive elements translate `translate-x-[3px] translate-y-[3px]` while collapsing their shadow to `shadow-[0px_0px_0px_#0A0A0A]`, simulating a mechanical button being physically pushed.
- **Halftone Texture Surfaces:** Secondary depth in featured headers, ticket stubs, or background hero sections uses CSS radial-gradient dots (Ben-Day halftone screens): 3px `#0A0A0A` dots spaced 12px apart at 8-12% opacity.

## Shapes

The design system uses deliberate, semi-soft comic panel borders (`roundedness: 1`). 

- Default elements (cards, inputs, banners) use `0.25rem` (`4px`) corner radii.
- Prominent components (ticket cards, modal dialogs) scale up to `rounded-lg` (`0.5rem` / `8px`).
- Badges and Starbursts break from standard roundedness: status chips use full capsules (`rounded-full`), while promotional callouts utilize geometric multi-point starburst clip-paths (`polygon`).
- **Border Weight:** All structural elements maintain a strict 2.5px (`border-[2.5px] border-black`) or 2px solid outer boundary line.

## Components

### Buttons
- **Primary Action (Ticket Checkout / Purchase):** Background in Electric Cobalt (`#2563EB`) or Vermilion (`#F43F5E`), text in `#FAF8F5`, enclosed by `border-[2.5px] border-black` with `shadow-[3px_3px_0px_#0A0A0A]`. On tap: translates `translate-x-[3px] translate-y-[3px]` with zero shadow.
- **Secondary Action:** Background in `#FAF8F5` or Canary Yellow (`#FACC15`), black bold label text, matching hard border and offset shadow.

### Cards & Ticket Modules
- **Event Card:** White/Cream surface (`#FFFDF0`) encased in `border-[2.5px] border-black` and `shadow-[4px_4px_0px_#0A0A0A]`. Header images feature sharp borders with optional halftone overlays on hover.
- **Physical Ticket Stub:** Features an authentic perforated cutout line (`border-dashed border-t-2 border-black`) separating the QR Code / Barcode section from event details, flanked by inward semi-circle cutouts on left and right borders.

### Badges, Chips & Starbursts
- **Filter Chips:** Pill-shaped (`rounded-full`), `border-2 border-black`, background in `#FAF8F5`. When active, fills with `#FACC15` or `#2563EB` with bold contrasting text.
- **Promo Starburst Badges:** CSS clip-path starbursts in `#FACC15` rotated at -4deg containing bold uppercase text (e.g., "AI PICK!", "VIP ACCESS", "EARLY BIRD").

### Input Fields & Controls
- **Text Inputs:** Crisp `#FFFDF0` field, `border-[2.5px] border-black`, `shadow-[2px_2px_0px_#0A0A0A]`. Focused state shifts shadow to Electric Cobalt (`shadow-[3px_3px_0px_#2563EB]`).
- **Checkboxes & Radios:** `border-2 border-black` squares or circles. Checked state fills with `#F43F5E` or `#2563EB` containing a heavy black check icon.

### Scannable AI Barcodes & QR Containers
- Encased inside dedicated high-contrast ivory boxes with thick border outlines and clean corner markers to ensure instantaneous optical scanner recognition under festival lighting.