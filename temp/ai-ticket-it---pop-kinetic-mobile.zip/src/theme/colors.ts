/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Pop Kinetic Ticketing Color Palette
 * Derived from Stitch Design System: Mid-century Pop Art, Lichtenstein primaries,
 * uncoated newsprint paper stock and jet-black graphic ink.
 */

export const Colors = {
  // Paper & Surfaces
  canvasBase: '#FAF8F5',       // Primary newsprint stock
  canvasTint: '#FFFDF0',       // Secondary container / elevated ticket card
  surfaceDim: '#DBDAD7',
  surfaceContainer: '#EFEEEB',
  surfaceHigh: '#EAE8E5',
  surfaceVariant: '#E4E2DF',
  
  // Lichtenstein Primary Graphic Inks
  electricCobalt: '#2563EB',   // Primary CTA, active states, verified badge
  cobaltDark: '#004AC6',       // Deep cobalt accent
  cobaltLight: '#DBE1FF',      // Cobalt tint container
  
  popVermilion: '#F43F5E',     // Hot magenta / vermilion: urgent alerts, hearts, sold out
  vermilionDark: '#B90538',
  vermilionLight: '#FFDADB',
  
  canaryYellow: '#FACC15',     // Tertiary punch: VIP upgrades, starbursts, tickers
  canaryDark: '#CEA700',
  canaryLight: '#FFE083',
  
  // Structural Graphics
  inkBlack: '#0A0A0A',         // 2.5px borders, hard offset drop shadows, comic lines
  inkBlackMuted: '#1B1C1A',
  
  // Utilities & Typography
  onSurface: '#1B1C1A',
  onSurfaceVariant: '#434655',
  outline: '#737686',
  outlineVariant: '#C3C6D7',
  white: '#FFFFFF',
  
  // Semantic
  error: '#BA1A1A',
  errorContainer: '#FFDAD6',
  success: '#10B981',
  successLight: '#D1FAE5',
} as const;

export type ColorType = keyof typeof Colors;
