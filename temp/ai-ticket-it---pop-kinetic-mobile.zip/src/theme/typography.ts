/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Pop Kinetic Typography Scale
 * Headlines: Bricolage Grotesque (Bold comic flare, ink traps)
 * Body & Metadata: Space Grotesk (Geometric, legible, technical)
 */

import { TextStyle } from 'react-native';

export const Typography: Record<string, TextStyle> = {
  headlineXl: {
    fontFamily: 'Bricolage Grotesque, system-ui, sans-serif',
    fontSize: 34,
    fontWeight: '800',
    lineHeight: 40,
    letterSpacing: -0.8,
  },
  headlineLg: {
    fontFamily: 'Bricolage Grotesque, system-ui, sans-serif',
    fontSize: 26,
    fontWeight: '700',
    lineHeight: 32,
    letterSpacing: -0.5,
  },
  headlineMd: {
    fontFamily: 'Bricolage Grotesque, system-ui, sans-serif',
    fontSize: 20,
    fontWeight: '700',
    lineHeight: 26,
    letterSpacing: -0.3,
  },
  titleLg: {
    fontFamily: 'Space Grotesk, monospace, sans-serif',
    fontSize: 18,
    fontWeight: '700',
    lineHeight: 24,
  },
  titleMd: {
    fontFamily: 'Space Grotesk, monospace, sans-serif',
    fontSize: 16,
    fontWeight: '600',
    lineHeight: 22,
  },
  bodyLg: {
    fontFamily: 'Space Grotesk, monospace, sans-serif',
    fontSize: 15,
    fontWeight: '400',
    lineHeight: 22,
  },
  bodyMd: {
    fontFamily: 'Space Grotesk, monospace, sans-serif',
    fontSize: 13,
    fontWeight: '400',
    lineHeight: 18,
  },
  labelLg: {
    fontFamily: 'Space Grotesk, monospace, sans-serif',
    fontSize: 13,
    fontWeight: '700',
    lineHeight: 16,
    letterSpacing: 0.8,
    textTransform: 'uppercase',
  },
  labelMd: {
    fontFamily: 'Space Grotesk, monospace, sans-serif',
    fontSize: 11,
    fontWeight: '700',
    lineHeight: 14,
    letterSpacing: 0.6,
    textTransform: 'uppercase',
  },
  labelSm: {
    fontFamily: 'Space Grotesk, monospace, sans-serif',
    fontSize: 9,
    fontWeight: '700',
    lineHeight: 12,
    letterSpacing: 0.8,
    textTransform: 'uppercase',
  },
};
