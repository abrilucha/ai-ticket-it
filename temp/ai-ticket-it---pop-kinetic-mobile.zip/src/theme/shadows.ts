/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Pop Kinetic Offset Shadows & Comic Borders
 * Hard-edged 0px blur solid #0A0A0A drop shadows with physical kinetic compression.
 */

import { ViewStyle } from 'react-native';
import { Colors } from './colors';

export const Shadows = {
  // Resting card / container: 4px offset
  card: {
    shadowColor: Colors.inkBlack,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 1,
    shadowRadius: 0,
    elevation: 4,
    // Cross-platform web fallback
    boxShadow: '4px 4px 0px #0A0A0A',
  } as ViewStyle,

  // Interactive buttons and chips: 3px offset
  interactive: {
    shadowColor: Colors.inkBlack,
    shadowOffset: { width: 3, height: 3 },
    shadowOpacity: 1,
    shadowRadius: 0,
    elevation: 3,
    boxShadow: '3px 3px 0px #0A0A0A',
  } as ViewStyle,

  // Small badges or mini-tags: 2px offset
  small: {
    shadowColor: Colors.inkBlack,
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 1,
    shadowRadius: 0,
    elevation: 2,
    boxShadow: '2px 2px 0px #0A0A0A',
  } as ViewStyle,

  // Elevated modal sheets: 6-8px offset
  modal: {
    shadowColor: Colors.inkBlack,
    shadowOffset: { width: 6, height: 6 },
    shadowOpacity: 1,
    shadowRadius: 0,
    elevation: 8,
    boxShadow: '6px 6px 0px #0A0A0A',
  } as ViewStyle,

  // Compressed active state (simulates mechanical button depress)
  pressed: {
    shadowColor: Colors.inkBlack,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0,
    shadowRadius: 0,
    elevation: 0,
    boxShadow: '0px 0px 0px #0A0A0A',
    transform: [{ translateX: 3 }, { translateY: 3 }],
  } as ViewStyle,
};

export const Borders = {
  thick: {
    borderWidth: 2.5,
    borderColor: Colors.inkBlack,
  },
  standard: {
    borderWidth: 2,
    borderColor: Colors.inkBlack,
  },
  hairline: {
    borderWidth: 1.5,
    borderColor: Colors.inkBlack,
  },
};
