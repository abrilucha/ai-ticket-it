/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * AI Ticket It - Pop Kinetic Mobile Application
 * Senior Frontend Mobile Engineer Architecture
 * Built with React Native & Expo component standards, StyleSheet,
 * and mid-century Pop Art / Lichtenstein visual design system.
 */

import React, { useState } from 'react';
import {
  View,
  Text,
  Pressable,
  StyleSheet,
  Alert,
} from 'react-native';
import { Colors } from './theme/colors';
import { Typography } from './theme/typography';
import { Shadows, Borders } from './theme/shadows';
import { EventItem, TicketTier, UserTicket } from './types/ticket';
import { MOCK_EVENTS, MOCK_USER_TICKETS } from './data/mockEvents';
import { HomeScreen } from './screens/HomeScreen';
import { TicketDetailScreen } from './screens/TicketDetailScreen';
import { MyTicketsScreen } from './screens/MyTicketsScreen';
import { ScanVerifyScreen } from './screens/ScanVerifyScreen';
import { AIVibeModal } from './components/AIVibeModal';

type ActiveTab = 'DISCOVER' | 'SEARCH' | 'TICKETS' | 'SCANNER';
type DeviceFrame = 'IPHONE' | 'PIXEL' | 'FULLSCREEN';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('DISCOVER');
  const [deviceFrame, setDeviceFrame] = useState<DeviceFrame>('IPHONE');
  const [selectedEvent, setSelectedEvent] = useState<EventItem | null>(null);
  const [userTickets, setUserTickets] = useState<UserTicket[]>(MOCK_USER_TICKETS);
  const [showVibeModal, setShowVibeModal] = useState<boolean>(false);
  const [showCodeInspector, setShowCodeInspector] = useState<boolean>(false);
  const [inspectedFile, setInspectedFile] = useState<string>('TicketStub.tsx');
  const [copiedNotification, setCopiedNotification] = useState<boolean>(false);

  // Handle purchasing tickets and generating new authentic ticket stub
  const handleCheckout = (event: EventItem, tier: TicketTier, quantity: number) => {
    const randomCodeNum = Math.floor(10000 + Math.random() * 90000);
    const newTicket: UserTicket = {
      id: `usr-tk-${Date.now()}`,
      ticketCode: `TK-POP-${randomCodeNum}`,
      eventId: event.id,
      eventTitle: event.title,
      artist: event.artist,
      venue: event.venue,
      date: event.date,
      time: event.time,
      tierName: tier.name,
      seatInfo: `Floor · Row A · Pass 01 of 0${quantity}`,
      gateInfo: 'Gate A · Priority AI Fast Pass',
      qrCodeUrl: `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=AI-TICKET-IT-TK-POP-${randomCodeNum}-SECURE-ENTRY`,
      barcodeNumber: `${randomCodeNum} 4482 9901 3320`,
      bannerImage: event.bannerImage,
      securityHash: `SHA256:${Math.random().toString(16).substring(2, 18)}`,
      status: 'ACTIVE',
      purchasedAt: new Date().toISOString().split('T')[0],
      aiVerifyStatus: 'CRYPTOGRAPHIC_VERIFIED',
    };

    setUserTickets((prev) => [newTicket, ...prev]);
    setSelectedEvent(null);
    setActiveTab('TICKETS');

    Alert.alert(
      '🎉 TICKETS SECURED!',
      `You secured ${quantity}x ${tier.name} for ${event.title}. Your physical stub with scannable QR is ready in your vault.`
    );
  };

  const codeSnippets: Record<string, string> = {
    'TicketStub.tsx': `import React, { useState } from 'react';
import { View, Text, Image, Pressable, StyleSheet } from 'react-native';

export const TicketStub = ({ ticket, onAddToWallet, onPressQR }) => {
  return (
    <View style={styles.stubContainer}>
      {/* Top Header */}
      <View style={styles.topSection}>
        <Image source={{ uri: ticket.bannerImage }} style={styles.thumbnail} />
        <Text style={styles.eventTitle}>{ticket.eventTitle}</Text>
        <Text style={styles.artistName}>{ticket.artist}</Text>
      </View>

      {/* Inward Semi-Circle Notches & Dashed Perforation */}
      <View style={styles.perforationRow}>
        <View style={styles.cutoutLeft} />
        <View style={styles.perforatedLine} />
        <View style={styles.cutoutRight} />
      </View>

      {/* Optical Scannable QR & Cryptographic Barcode */}
      <View style={styles.bottomSection}>
        <View style={styles.qrContainerBox}>
          <Image source={{ uri: ticket.qrCodeUrl }} style={styles.qrImage} />
        </View>
        <Text style={styles.barcodeText}>{ticket.barcodeNumber}</Text>
      </View>
    </View>
  );
};`,
    'EventCard.tsx': `import React from 'react';
import { View, Text, Image, Pressable, StyleSheet } from 'react-native';

export const EventCard = ({ event, onPress, onVibeCheckPress }) => {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.cardContainer,
        pressed ? styles.pressed : styles.resting,
      ]}
    >
      <Image source={{ uri: event.bannerImage }} style={styles.image} />
      <View style={styles.aiMatchBadge}>
        <Text style={styles.aiMatchText}>{event.aiAnalysis.matchScore}% MATCH</Text>
      </View>
      <Text style={styles.title}>{event.title}</Text>
      <Text style={styles.artist}>{event.artist}</Text>
    </Pressable>
  );
};`,
    'PopButton.tsx': `import React from 'react';
import { Pressable, Text, StyleSheet } from 'react-native';

export const PopButton = ({ label, onPress, variant = 'primary', size = 'md' }) => {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.base,
        styles[variant],
        styles[size],
        pressed ? styles.pressed : styles.shadow,
      ]}
    >
      <Text style={styles.label}>{label}</Text>
    </Pressable>
  );
};`,
  };

  const handleCopyCode = () => {
    navigator.clipboard?.writeText(codeSnippets[inspectedFile] || '');
    setCopiedNotification(true);
    setTimeout(() => setCopiedNotification(false), 2000);
  };

  return (
    <div className="min-h-screen bg-[#1B1C1A] text-[#FAF8F5] flex flex-col items-center justify-between font-sans">
      {/* Dev & Studio Navigation Header */}
      <header className="w-full bg-[#0A0A0A] border-b-2 border-[#2563EB] px-4 py-3 flex flex-wrap items-center justify-between gap-3 z-50">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-[#FACC15] border-2 border-black flex items-center justify-center font-black text-black text-lg">
            ⚡
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-sm tracking-wider uppercase text-[#FAF8F5]">
                AI Ticket It · Expo & React Native Architecture
              </span>
              <span className="bg-[#2563EB] text-[#FAF8F5] text-[10px] font-bold px-2 py-0.5 rounded border border-black uppercase">
                Mobile Native
              </span>
            </div>
            <span className="text-[11px] text-[#A0A0A0]">
              Pop Kinetic Ticketing · Lichtenstein Primaries · Perforated Physical Stubs
            </span>
          </div>
        </div>

        {/* Device Frame & Inspector Controls */}
        <div className="flex items-center gap-2">
          {/* Device Model Switcher */}
          <div className="flex items-center bg-[#242523] p-1 rounded border border-neutral-700">
            <button
              onClick={() => setDeviceFrame('IPHONE')}
              className={`px-2.5 py-1 text-xs font-bold rounded transition-colors ${
                deviceFrame === 'IPHONE'
                  ? 'bg-[#2563EB] text-white'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              📱 iOS (iPhone 16)
            </button>
            <button
              onClick={() => setDeviceFrame('PIXEL')}
              className={`px-2.5 py-1 text-xs font-bold rounded transition-colors ${
                deviceFrame === 'PIXEL'
                  ? 'bg-[#2563EB] text-white'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              🤖 Android (Pixel)
            </button>
            <button
              onClick={() => setDeviceFrame('FULLSCREEN')}
              className={`px-2.5 py-1 text-xs font-bold rounded transition-colors ${
                deviceFrame === 'FULLSCREEN'
                  ? 'bg-[#2563EB] text-white'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              🖥️ Fluid
            </button>
          </div>

          {/* Code Inspector Toggle */}
          <button
            onClick={() => setShowCodeInspector(!showCodeInspector)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#FACC15] text-black font-extrabold text-xs rounded border-2 border-black hover:bg-yellow-400 active:translate-y-0.5 transition-all shadow-[2px_2px_0px_#000]"
          >
            <span>📜</span>
            <span>{showCodeInspector ? 'HIDE EXPO CODE' : 'INSPECT EXPO CODE'}</span>
          </button>
        </div>
      </header>

      {/* Main Workspace Body */}
      <main className="w-full flex-1 flex flex-col lg:flex-row items-center justify-center p-3 lg:p-6 overflow-hidden gap-6">
        {/* Device Canvas Frame */}
        <div className="flex items-center justify-center w-full flex-1 max-w-full">
          <div
            style={{
              width: deviceFrame === 'FULLSCREEN' ? '100%' : 393,
              maxWidth: deviceFrame === 'FULLSCREEN' ? 520 : 393,
              height: deviceFrame === 'FULLSCREEN' ? '88vh' : 820,
              maxHeight: '92vh',
            }}
            className={`flex flex-col bg-[#FAF8F5] relative overflow-hidden transition-all duration-300 ${
              deviceFrame !== 'FULLSCREEN'
                ? 'rounded-[44px] border-[10px] border-[#0A0A0A] shadow-[0_25px_60px_-15px_rgba(0,0,0,0.85)] ring-1 ring-neutral-700'
                : 'rounded-xl border-4 border-[#0A0A0A]'
            }`}
          >
            {/* Native Mobile Status Bar & Dynamic Island */}
            {deviceFrame !== 'FULLSCREEN' && (
              <div className="w-full bg-[#FAF8F5] px-6 pt-3 pb-2 flex items-center justify-between text-xs font-bold text-[#0A0A0A] z-40 select-none">
                <span>9:41</span>
                {deviceFrame === 'IPHONE' ? (
                  <div className="w-24 h-4 bg-[#0A0A0A] rounded-full mx-auto" />
                ) : (
                  <div className="w-3.5 h-3.5 bg-[#0A0A0A] rounded-full mx-auto" />
                )}
                <div className="flex items-center gap-1.5 text-[11px]">
                  <span>5G</span>
                  <span>100%</span>
                  <span>🔋</span>
                </div>
              </div>
            )}

            {/* SCREEN ROUTING CONTAINER */}
            <div className="flex-1 flex flex-col overflow-hidden relative">
              {selectedEvent ? (
                <TicketDetailScreen
                  event={selectedEvent}
                  onBack={() => setSelectedEvent(null)}
                  onCheckout={handleCheckout}
                  onOpenVibeModal={() => setShowVibeModal(true)}
                />
              ) : activeTab === 'DISCOVER' ? (
                <HomeScreen
                  onSelectEvent={(event) => setSelectedEvent(event)}
                  onNavigateToWallet={() => setActiveTab('TICKETS')}
                />
              ) : activeTab === 'SEARCH' ? (
                <HomeScreen
                  onSelectEvent={(event) => setSelectedEvent(event)}
                  onNavigateToWallet={() => setActiveTab('TICKETS')}
                />
              ) : activeTab === 'TICKETS' ? (
                <MyTicketsScreen
                  tickets={userTickets}
                  onScanPress={() => setActiveTab('SCANNER')}
                  onExplorePress={() => setActiveTab('DISCOVER')}
                />
              ) : (
                <ScanVerifyScreen
                  onBack={() => setActiveTab('TICKETS')}
                  onTicketVerified={(code) => {
                    Alert.alert('SUCCESS', `Ticket ${code} authenticated by turnstile!`);
                  }}
                />
              )}
            </div>

            {/* REACT NATIVE BOTTOM TAB BAR */}
            <View style={tabStyles.tabBar}>
              <Pressable
                onPress={() => {
                  setSelectedEvent(null);
                  setActiveTab('DISCOVER');
                }}
                style={[
                  tabStyles.tabButton,
                  activeTab === 'DISCOVER' && !selectedEvent && tabStyles.tabButtonActive,
                ]}
              >
                <Text style={tabStyles.tabIcon}>⚡</Text>
                <Text
                  style={[
                    tabStyles.tabLabel,
                    activeTab === 'DISCOVER' && !selectedEvent && tabStyles.tabLabelActive,
                  ]}
                >
                  DISCOVER
                </Text>
              </Pressable>

              <Pressable
                onPress={() => {
                  setSelectedEvent(null);
                  setActiveTab('SEARCH');
                }}
                style={[
                  tabStyles.tabButton,
                  activeTab === 'SEARCH' && tabStyles.tabButtonActive,
                ]}
              >
                <Text style={tabStyles.tabIcon}>🔍</Text>
                <Text
                  style={[
                    tabStyles.tabLabel,
                    activeTab === 'SEARCH' && tabStyles.tabLabelActive,
                  ]}
                >
                  AI VIBES
                </Text>
              </Pressable>

              <Pressable
                onPress={() => {
                  setSelectedEvent(null);
                  setActiveTab('TICKETS');
                }}
                style={[
                  tabStyles.tabButton,
                  activeTab === 'TICKETS' && tabStyles.tabButtonActive,
                ]}
              >
                <Text style={tabStyles.tabIcon}>🎟️</Text>
                <Text
                  style={[
                    tabStyles.tabLabel,
                    activeTab === 'TICKETS' && tabStyles.tabLabelActive,
                  ]}
                >
                  VAULT ({userTickets.length})
                </Text>
              </Pressable>

              <Pressable
                onPress={() => {
                  setSelectedEvent(null);
                  setActiveTab('SCANNER');
                }}
                style={[
                  tabStyles.tabButton,
                  activeTab === 'SCANNER' && tabStyles.tabButtonActive,
                ]}
              >
                <Text style={tabStyles.tabIcon}>📷</Text>
                <Text
                  style={[
                    tabStyles.tabLabel,
                    activeTab === 'SCANNER' && tabStyles.tabLabelActive,
                  ]}
                >
                  SCANNER
                </Text>
              </Pressable>
            </View>

            {/* Native Home Indicator Bar for iOS */}
            {deviceFrame === 'IPHONE' && (
              <div className="w-full bg-[#FAF8F5] pb-2 pt-1 flex justify-center select-none">
                <div className="w-32 h-1 bg-[#0A0A0A] rounded-full" />
              </div>
            )}
          </div>
        </div>

        {/* Code Inspector Drawer */}
        {showCodeInspector && (
          <aside className="w-full lg:w-[420px] h-[550px] lg:h-[820px] bg-[#0A0A0A] border-2 border-neutral-700 rounded-xl flex flex-col overflow-hidden shadow-2xl">
            {/* Drawer Header */}
            <div className="bg-[#1F201E] px-4 py-3 border-b border-neutral-700 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-yellow-400 font-mono text-xs font-bold">
                  📁 EXPO SOURCE CODE
                </span>
                <span className="text-[10px] bg-blue-900 text-blue-200 px-1.5 py-0.5 rounded">
                  TypeScript
                </span>
              </div>
              <button
                onClick={handleCopyCode}
                className="px-2.5 py-1 bg-[#2563EB] hover:bg-blue-600 text-white text-xs font-bold rounded flex items-center gap-1 transition-all"
              >
                <span>{copiedNotification ? '✓ COPIED!' : '📋 COPY FILE'}</span>
              </button>
            </div>

            {/* File Switcher Tabs */}
            <div className="flex border-b border-neutral-800 bg-[#141513] px-2 py-1 gap-1">
              {Object.keys(codeSnippets).map((filename) => (
                <button
                  key={filename}
                  onClick={() => setInspectedFile(filename)}
                  className={`px-3 py-1 text-xs font-mono rounded ${
                    inspectedFile === filename
                      ? 'bg-[#2563EB] text-white font-bold'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  {filename}
                </button>
              ))}
            </div>

            {/* Code View Area */}
            <div className="flex-1 p-4 overflow-y-auto font-mono text-xs text-neutral-300 bg-[#0A0A0A] leading-relaxed">
              <pre className="whitespace-pre-wrap">{codeSnippets[inspectedFile]}</pre>
            </div>

            {/* Expo Run Instructions Footer */}
            <div className="p-3 bg-[#161715] border-t border-neutral-800 text-[11px] text-neutral-400">
              <p className="font-bold text-neutral-200 mb-1">
                🚀 How to test in React Native with Expo:
              </p>
              <code className="text-[#FACC15] block bg-black p-1.5 rounded font-mono text-[10px] mb-1">
                npx create-expo-app ai-ticket-it --template blank-typescript
              </code>
              <p>
                Drop <span className="text-blue-400">src/components</span> &{' '}
                <span className="text-blue-400">src/theme</span> into your Expo project folder. Zero web dependencies.
              </p>
            </div>
          </aside>
        )}
      </main>

      {/* Global AI Vibe Modal */}
      {selectedEvent && (
        <AIVibeModal
          visible={showVibeModal}
          event={selectedEvent}
          onClose={() => setShowVibeModal(false)}
          onSelectTier={() => {
            setShowVibeModal(false);
          }}
        />
      )}
    </div>
  );
}

const tabStyles = StyleSheet.create({
  tabBar: {
    flexDirection: 'row',
    backgroundColor: Colors.canvasTint,
    borderTopWidth: 2.5,
    borderTopColor: Colors.inkBlack,
    paddingVertical: 8,
    paddingHorizontal: 8,
    justifyContent: 'space-around',
    alignItems: 'center',
    zIndex: 30,
  },
  tabButton: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 6,
    borderRadius: 4,
  },
  tabButtonActive: {
    backgroundColor: Colors.canaryYellow,
    ...Borders.thick,
    ...Shadows.small,
  },
  tabIcon: {
    fontSize: 16,
    marginBottom: 2,
  },
  tabLabel: {
    ...Typography.labelSm,
    fontSize: 9,
    color: Colors.inkBlack,
    fontWeight: '700',
  },
  tabLabelActive: {
    fontWeight: '900',
  },
});
