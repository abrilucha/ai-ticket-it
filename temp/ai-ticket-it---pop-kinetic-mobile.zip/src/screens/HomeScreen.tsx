/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * HomeScreen (React Native & Expo)
 * Discovery feed featuring Lichtenstein headline framing, AI affinity carousel,
 * filter chips, and kinetic event panel cards.
 */

import React, { useState } from 'react';
import {
  View,
  Text,
  FlatList,
  Pressable,
  StyleSheet,
} from 'react-native';
import { Colors } from '../theme/colors';
import { Typography } from '../theme/typography';
import { Shadows, Borders } from '../theme/shadows';
import { EventCategory, EventItem } from '../types/ticket';
import { MOCK_EVENTS } from '../data/mockEvents';
import { EventCard } from '../components/EventCard';
import { FilterChip } from '../components/FilterChip';
import { SearchBar } from '../components/SearchBar';
import { StarburstBadge } from '../components/StarburstBadge';
import { AIVibeModal } from '../components/AIVibeModal';

const CATEGORIES: EventCategory[] = [
  'ALL',
  'CONCERTS',
  'FESTIVALS',
  'EXHIBITS',
  'INDIE',
  'TECH & AI',
];

export interface HomeScreenProps {
  onSelectEvent: (event: EventItem) => void;
  onNavigateToWallet: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onSelectEvent,
  onNavigateToWallet,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<EventCategory>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [modalEvent, setModalEvent] = useState<EventItem | null>(null);

  // Filter events based on category and search query
  const filteredEvents = MOCK_EVENTS.filter((ev) => {
    const matchesCat = selectedCategory === 'ALL' || ev.category === selectedCategory;
    const matchesQuery =
      searchQuery.trim() === '' ||
      ev.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ev.artist.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ev.venue.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ev.aiAnalysis.vibeTags.some((tag) =>
        tag.toLowerCase().includes(searchQuery.toLowerCase())
      );
    return matchesCat && matchesQuery;
  });

  const featuredEvents = MOCK_EVENTS.filter((ev) => ev.aiAnalysis.matchScore >= 92);

  return (
    <View style={styles.screenRoot}>
      {/* Pop Art Top App Bar */}
      <View style={styles.appBar}>
        <View style={styles.brandingCol}>
          <View style={styles.brandTitleRow}>
            <Text style={styles.brandLogo}>AI TICKET</Text>
            <View style={styles.itBadge}>
              <Text style={styles.itBadgeText}>IT!</Text>
            </View>
          </View>
          <Text style={styles.tagline}>POP KINETIC MOBILE</Text>
        </View>

        <Pressable
          onPress={onNavigateToWallet}
          style={({ pressed }) => [
            styles.ticketWalletButton,
            pressed ? Shadows.pressed : Shadows.interactive,
          ]}
        >
          <Text style={styles.ticketWalletIcon}>🎟️</Text>
          <View style={styles.ticketWalletBadge}>
            <Text style={styles.ticketWalletBadgeText}>2</Text>
          </View>
        </Pressable>
      </View>

      {/* Main Scrollable Content */}
      <FlatList
        data={filteredEvents}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.listContent}
        ListHeaderComponent={
          <View style={styles.headerComponent}>
            {/* Search Bar with AI Trigger */}
            <View style={styles.searchSlot}>
              <SearchBar
                value={searchQuery}
                onChangeText={setSearchQuery}
                onAISearchPress={() => setSearchQuery('Modular')}
              />
            </View>

            {/* Filter Chips Horizontal Carousel */}
            <FlatList
              horizontal
              data={CATEGORIES}
              keyExtractor={(cat) => cat}
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.chipsContainer}
              renderItem={({ item: cat }) => (
                <FilterChip
                  label={cat}
                  selected={selectedCategory === cat}
                  onPress={() => setSelectedCategory(cat)}
                  activeColor={cat === 'CONCERTS' ? 'cobalt' : cat === 'FESTIVALS' ? 'vermilion' : 'yellow'}
                />
              )}
            />

            {/* AI Curated Kinetic Banner */}
            <View style={[styles.aiAnnouncementBanner, Shadows.card]}>
              <View style={styles.announcementLeft}>
                <StarburstBadge label="AI PULSE" variant="vermilion" rotation={-4} size="sm" />
                <Text style={styles.announcementTitle}>POP RADAR ACTIVE</Text>
                <Text style={styles.announcementBody}>
                  3 shows detected within 5 miles matching your post-punk & synthwave tastes.
                </Text>
              </View>
              <View style={styles.announcementGraphic}>
                <Text style={styles.soundWaveIcon}>⚡📻</Text>
              </View>
            </View>

            {/* Featured AI Carousel */}
            {searchQuery === '' && selectedCategory === 'ALL' && (
              <View style={styles.featuredSection}>
                <View style={styles.sectionHeaderRow}>
                  <Text style={styles.sectionTitle}>AI HIGH AFFINITY PICKS</Text>
                  <Text style={styles.sectionBadge}>OVER 90% MATCH</Text>
                </View>

                <FlatList
                  horizontal
                  data={featuredEvents}
                  keyExtractor={(item) => `feat-${item.id}`}
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={styles.featuredCarousel}
                  renderItem={({ item }) => (
                    <EventCard
                      event={item}
                      featured
                      onPress={() => onSelectEvent(item)}
                      onVibeCheckPress={() => setModalEvent(item)}
                    />
                  )}
                />
              </View>
            )}

            {/* Section Divider & Title */}
            <View style={styles.sectionHeaderRow}>
              <Text style={styles.sectionTitle}>
                {selectedCategory === 'ALL' ? 'ALL LIVE DROPS' : `${selectedCategory} DROPS`}
              </Text>
              <Text style={styles.countLabel}>{filteredEvents.length} AVAILABLE</Text>
            </View>
          </View>
        }
        renderItem={({ item }) => (
          <EventCard
            event={item}
            onPress={() => onSelectEvent(item)}
            onVibeCheckPress={() => setModalEvent(item)}
          />
        )}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyIcon}>🎨</Text>
            <Text style={styles.emptyTitle}>NO TICKETS FOUND</Text>
            <Text style={styles.emptySubtitle}>
              Try tweaking your search or tap a different category filter.
            </Text>
          </View>
        }
      />

      {/* AI Vibe Modal Breakdown */}
      <AIVibeModal
        visible={modalEvent !== null}
        event={modalEvent}
        onClose={() => setModalEvent(null)}
        onSelectTier={() => {
          if (modalEvent) {
            onSelectEvent(modalEvent);
          }
        }}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  screenRoot: {
    flex: 1,
    backgroundColor: Colors.canvasBase,
  },
  appBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 12,
    backgroundColor: Colors.canvasBase,
    borderBottomWidth: 2.5,
    borderBottomColor: Colors.inkBlack,
  },
  brandingCol: {
    flexDirection: 'column',
  },
  brandTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  brandLogo: {
    ...Typography.headlineXl,
    fontSize: 24,
    lineHeight: 28,
    color: Colors.inkBlack,
    letterSpacing: -0.5,
  },
  itBadge: {
    backgroundColor: Colors.popVermilion,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 3,
    ...Borders.thick,
    marginLeft: 6,
    transform: [{ rotate: '4deg' }],
  },
  itBadgeText: {
    ...Typography.labelSm,
    fontSize: 10,
    fontWeight: '800',
    color: Colors.canvasBase,
  },
  tagline: {
    ...Typography.labelSm,
    fontSize: 9,
    color: Colors.outline,
    letterSpacing: 1.2,
    marginTop: 2,
  },
  ticketWalletButton: {
    backgroundColor: Colors.canaryYellow,
    width: 44,
    height: 44,
    borderRadius: 6,
    ...Borders.thick,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  ticketWalletIcon: {
    fontSize: 20,
  },
  ticketWalletBadge: {
    position: 'absolute',
    top: -5,
    right: -5,
    backgroundColor: Colors.popVermilion,
    width: 18,
    height: 18,
    borderRadius: 9,
    ...Borders.hairline,
    alignItems: 'center',
    justifyContent: 'center',
  },
  ticketWalletBadgeText: {
    ...Typography.labelSm,
    fontSize: 9,
    fontWeight: '800',
    color: Colors.canvasBase,
  },
  listContent: {
    paddingHorizontal: 16,
    paddingBottom: 40,
  },
  headerComponent: {
    paddingTop: 14,
  },
  searchSlot: {
    marginBottom: 12,
  },
  chipsContainer: {
    paddingBottom: 12,
  },
  aiAnnouncementBanner: {
    backgroundColor: Colors.canaryYellow,
    borderRadius: 6,
    ...Borders.thick,
    padding: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  announcementLeft: {
    flex: 1,
    marginRight: 10,
  },
  announcementTitle: {
    ...Typography.titleMd,
    fontWeight: '800',
    color: Colors.inkBlack,
    marginTop: 6,
    marginBottom: 2,
  },
  announcementBody: {
    ...Typography.bodyMd,
    fontSize: 12,
    color: Colors.inkBlack,
  },
  announcementGraphic: {
    padding: 8,
    backgroundColor: Colors.canvasBase,
    borderRadius: 4,
    ...Borders.thick,
  },
  soundWaveIcon: {
    fontSize: 22,
  },
  featuredSection: {
    marginBottom: 20,
  },
  sectionHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  sectionTitle: {
    ...Typography.titleMd,
    fontWeight: '800',
    color: Colors.inkBlack,
    letterSpacing: 0.5,
  },
  sectionBadge: {
    ...Typography.labelSm,
    fontSize: 9,
    color: Colors.electricCobalt,
    backgroundColor: Colors.cobaltLight,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 3,
    ...Borders.hairline,
  },
  countLabel: {
    ...Typography.labelSm,
    fontSize: 9,
    color: Colors.outline,
  },
  featuredCarousel: {
    paddingBottom: 6,
  },
  emptyContainer: {
    padding: 40,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.canvasTint,
    borderRadius: 6,
    ...Borders.thick,
    marginTop: 20,
  },
  emptyIcon: {
    fontSize: 36,
    marginBottom: 10,
  },
  emptyTitle: {
    ...Typography.titleMd,
    fontWeight: '800',
    color: Colors.inkBlack,
  },
  emptySubtitle: {
    ...Typography.bodyMd,
    fontSize: 12,
    color: Colors.outline,
    textAlign: 'center',
    marginTop: 4,
  },
});
