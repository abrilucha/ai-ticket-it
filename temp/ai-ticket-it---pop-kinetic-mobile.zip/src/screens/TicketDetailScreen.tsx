/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * TicketDetailScreen (React Native & Expo)
 * Event deep-dive with tier selector, AI match affinity summary,
 * quantity stepper, and Lichtenstein checkout button.
 */

import React, { useState } from 'react';
import {
  View,
  Text,
  Image,
  ScrollView,
  Pressable,
  StyleSheet,
} from 'react-native';
import { Colors } from '../theme/colors';
import { Typography } from '../theme/typography';
import { Shadows, Borders } from '../theme/shadows';
import { EventItem, TicketTier } from '../types/ticket';
import { PopButton } from '../components/PopButton';
import { StarburstBadge } from '../components/StarburstBadge';

export interface TicketDetailScreenProps {
  event: EventItem;
  onBack: () => void;
  onCheckout: (event: EventItem, tier: TicketTier, quantity: number) => void;
  onOpenVibeModal: () => void;
}

export const TicketDetailScreen: React.FC<TicketDetailScreenProps> = ({
  event,
  onBack,
  onCheckout,
  onOpenVibeModal,
}) => {
  const [selectedTier, setSelectedTier] = useState<TicketTier>(event.tiers[0]);
  const [quantity, setQuantity] = useState<number>(1);

  const totalPrice = selectedTier ? selectedTier.price * quantity : 0;

  return (
    <View style={styles.screenRoot}>
      {/* Top Navigation Bar */}
      <View style={styles.navBar}>
        <Pressable
          onPress={onBack}
          style={({ pressed }) => [
            styles.backButton,
            pressed ? Shadows.pressed : Shadows.small,
          ]}
        >
          <Text style={styles.backButtonText}>← BACK</Text>
        </Pressable>

        <Text style={styles.navTitle} numberOfLines={1}>
          {event.title}
        </Text>

        <Pressable
          onPress={onOpenVibeModal}
          style={({ pressed }) => [
            styles.aiNavButton,
            pressed ? Shadows.pressed : Shadows.small,
          ]}
        >
          <Text style={styles.aiNavButtonText}>✨ AI INTEL</Text>
        </Pressable>
      </View>

      <ScrollView style={styles.scrollContainer} showsVerticalScrollIndicator={false}>
        {/* Big Hero Banner with Lichtenstein Frame */}
        <View style={styles.posterContainer}>
          <Image
            source={{ uri: event.bannerImage }}
            style={styles.posterImage}
            resizeMode="cover"
          />

          {event.promoBadge && (
            <View style={styles.starburstBadgeSlot}>
              <StarburstBadge label={event.promoBadge} variant="yellow" rotation={-5} />
            </View>
          )}

          {/* Floating AI Match Ribbon */}
          <View style={styles.floatingAffinityRibbon}>
            <Text style={styles.affinityIcon}>⚡</Text>
            <Text style={styles.affinityScore}>{event.aiAnalysis.matchScore}% MATCH</Text>
            <Text style={styles.affinitySub}>FOR YOUR VIBE</Text>
          </View>
        </View>

        {/* Content Box */}
        <View style={styles.bodyContent}>
          {/* Header Info */}
          <View style={styles.headerInfoBlock}>
            <View style={styles.categoryPill}>
              <Text style={styles.categoryPillText}>{event.category}</Text>
            </View>

            <Text style={styles.title}>{event.title}</Text>
            <Text style={styles.artist}>{event.artist}</Text>

            {/* Date, Time & Location Cards */}
            <View style={styles.infoGrid}>
              <View style={styles.infoCard}>
                <Text style={styles.infoCardLabel}>DATE & TIME</Text>
                <Text style={styles.infoCardValue}>{event.date}</Text>
                <Text style={styles.infoCardSub}>{event.time}</Text>
              </View>

              <View style={styles.infoCard}>
                <Text style={styles.infoCardLabel}>VENUE</Text>
                <Text style={styles.infoCardValue} numberOfLines={1}>
                  {event.venue}
                </Text>
                <Text style={styles.infoCardSub}>{event.city}</Text>
              </View>
            </View>
          </View>

          {/* AI Vibe Insights Card */}
          <View style={[styles.aiInsightCard, Shadows.card]}>
            <View style={styles.aiInsightHeader}>
              <Text style={styles.aiInsightTitle}>AI CONCIERGE RECOMMENDATION</Text>
              <Pressable onPress={onOpenVibeModal}>
                <Text style={styles.viewMoreAi}>VIEW ALL INTEL →</Text>
              </Pressable>
            </View>

            <Text style={styles.aiQuote}>"{event.aiAnalysis.curatorNote}"</Text>

            <View style={styles.intelChipsRow}>
              <View style={styles.intelChip}>
                <Text style={styles.intelChipText}>
                  🚦 Arrival: {event.aiAnalysis.bestArrivalTime}
                </Text>
              </View>
              <View style={styles.intelChip}>
                <Text style={styles.intelChipText}>
                  💰 Trend: {event.aiAnalysis.priceForecast}
                </Text>
              </View>
            </View>
          </View>

          {/* Ticket Tiers Selection */}
          <View style={styles.tiersSection}>
            <Text style={styles.sectionHeading}>SELECT TICKET TIER</Text>

            {event.tiers.map((tier) => {
              const isSelected = selectedTier?.id === tier.id;
              return (
                <Pressable
                  key={tier.id}
                  onPress={() => setSelectedTier(tier)}
                  style={({ pressed }) => [
                    styles.tierCard,
                    isSelected ? styles.tierCardSelected : styles.tierCardUnselected,
                    pressed ? Shadows.pressed : Shadows.interactive,
                  ]}
                >
                  <View style={styles.tierHeader}>
                    <View style={styles.tierNameCol}>
                      <View style={styles.tierBadgeRow}>
                        <Text style={styles.tierTitle}>{tier.name}</Text>
                        {tier.isPopular && (
                          <View style={styles.popularBadge}>
                            <Text style={styles.popularBadgeText}>POPULAR</Text>
                          </View>
                        )}
                      </View>
                      <Text style={styles.tierAvailability}>
                        {tier.availableCount} TICKETS REMAINING
                      </Text>
                    </View>

                    <Text style={styles.tierPrice}>${tier.price}</Text>
                  </View>

                  <View style={styles.perksList}>
                    {tier.perks.map((perk, idx) => (
                      <View key={idx} style={styles.perkItem}>
                        <Text style={styles.perkCheck}>✓</Text>
                        <Text style={styles.perkText}>{perk}</Text>
                      </View>
                    ))}
                  </View>
                </Pressable>
              );
            })}
          </View>

          {/* Quantity Stepper */}
          <View style={[styles.quantityBox, Shadows.card]}>
            <View>
              <Text style={styles.quantityTitle}>NUMBER OF PASSES</Text>
              <Text style={styles.quantitySub}>Max 6 per order</Text>
            </View>

            <View style={styles.stepperRow}>
              <Pressable
                onPress={() => setQuantity((q) => Math.max(1, q - 1))}
                style={({ pressed }) => [
                  styles.stepperButton,
                  pressed && Shadows.pressed,
                ]}
              >
                <Text style={styles.stepperButtonText}>-</Text>
              </Pressable>

              <View style={styles.quantityDisplay}>
                <Text style={styles.quantityNumber}>{quantity}</Text>
              </View>

              <Pressable
                onPress={() => setQuantity((q) => Math.min(6, q + 1))}
                style={({ pressed }) => [
                  styles.stepperButton,
                  pressed && Shadows.pressed,
                ]}
              >
                <Text style={styles.stepperButtonText}>+</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </ScrollView>

      {/* Sticky Bottom Checkout Footer */}
      <View style={styles.stickyFooter}>
        <View style={styles.footerPriceCol}>
          <Text style={styles.footerTotalLabel}>TOTAL AMOUNT</Text>
          <Text style={styles.footerTotalPrice}>${totalPrice}</Text>
          <Text style={styles.footerFeesLabel}>Taxes & AI security fee included</Text>
        </View>

        <View style={styles.footerCtaCol}>
          <PopButton
            label="SECURE PASSES"
            onPress={() => onCheckout(event, selectedTier, quantity)}
            variant="primary"
            size="lg"
          />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  screenRoot: {
    flex: 1,
    backgroundColor: Colors.canvasBase,
  },
  navBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: Colors.canvasBase,
    borderBottomWidth: 2.5,
    borderBottomColor: Colors.inkBlack,
  },
  backButton: {
    backgroundColor: Colors.canvasTint,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 4,
    ...Borders.thick,
  },
  backButtonText: {
    ...Typography.labelSm,
    fontWeight: '800',
    color: Colors.inkBlack,
  },
  navTitle: {
    ...Typography.titleMd,
    fontWeight: '800',
    color: Colors.inkBlack,
    maxWidth: 160,
  },
  aiNavButton: {
    backgroundColor: Colors.canaryYellow,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 4,
    ...Borders.thick,
  },
  aiNavButtonText: {
    ...Typography.labelSm,
    fontWeight: '800',
    color: Colors.inkBlack,
  },
  scrollContainer: {
    flex: 1,
  },
  posterContainer: {
    position: 'relative',
    borderBottomWidth: 2.5,
    borderBottomColor: Colors.inkBlack,
  },
  posterImage: {
    width: '100%',
    height: 220,
  },
  starburstBadgeSlot: {
    position: 'absolute',
    top: 14,
    left: 14,
  },
  floatingAffinityRibbon: {
    position: 'absolute',
    bottom: 12,
    right: 12,
    backgroundColor: Colors.canvasTint,
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 4,
    paddingHorizontal: 10,
    borderRadius: 4,
    ...Borders.thick,
    ...Shadows.small,
  },
  affinityIcon: {
    fontSize: 14,
    marginRight: 4,
  },
  affinityScore: {
    ...Typography.titleMd,
    fontSize: 13,
    fontWeight: '800',
    color: Colors.inkBlack,
    marginRight: 4,
  },
  affinitySub: {
    ...Typography.labelSm,
    fontSize: 9,
    color: Colors.outline,
  },
  bodyContent: {
    padding: 16,
    paddingBottom: 40,
  },
  headerInfoBlock: {
    marginBottom: 16,
  },
  categoryPill: {
    backgroundColor: Colors.electricCobalt,
    paddingVertical: 2,
    paddingHorizontal: 8,
    borderRadius: 3,
    alignSelf: 'flex-start',
    marginBottom: 6,
    ...Borders.hairline,
  },
  categoryPillText: {
    ...Typography.labelSm,
    fontSize: 9,
    color: Colors.canvasBase,
  },
  title: {
    ...Typography.headlineLg,
    fontSize: 24,
    lineHeight: 28,
    color: Colors.inkBlack,
  },
  artist: {
    ...Typography.titleLg,
    color: Colors.popVermilion,
    marginBottom: 14,
  },
  infoGrid: {
    flexDirection: 'row',
    gap: 8,
  },
  infoCard: {
    flex: 1,
    backgroundColor: Colors.canvasTint,
    padding: 10,
    borderRadius: 4,
    ...Borders.standard,
  },
  infoCardLabel: {
    ...Typography.labelSm,
    fontSize: 8,
    color: Colors.outline,
    marginBottom: 2,
  },
  infoCardValue: {
    ...Typography.titleMd,
    fontSize: 12,
    fontWeight: '800',
    color: Colors.inkBlack,
  },
  infoCardSub: {
    ...Typography.bodyMd,
    fontSize: 11,
    color: Colors.onSurfaceVariant,
  },
  aiInsightCard: {
    backgroundColor: Colors.canaryYellow,
    padding: 14,
    borderRadius: 6,
    ...Borders.thick,
    marginBottom: 20,
  },
  aiInsightHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  aiInsightTitle: {
    ...Typography.labelSm,
    fontSize: 10,
    color: Colors.inkBlack,
    fontWeight: '800',
  },
  viewMoreAi: {
    ...Typography.labelSm,
    fontSize: 9,
    color: Colors.electricCobalt,
    textDecorationLine: 'underline',
  },
  aiQuote: {
    ...Typography.bodyMd,
    fontSize: 12,
    fontStyle: 'italic',
    color: Colors.inkBlack,
    marginBottom: 10,
  },
  intelChipsRow: {
    flexDirection: 'row',
    gap: 6,
  },
  intelChip: {
    backgroundColor: Colors.canvasBase,
    paddingVertical: 3,
    paddingHorizontal: 8,
    borderRadius: 3,
    ...Borders.hairline,
  },
  intelChipText: {
    ...Typography.labelSm,
    fontSize: 9,
    color: Colors.inkBlack,
  },
  tiersSection: {
    marginBottom: 20,
  },
  sectionHeading: {
    ...Typography.labelLg,
    color: Colors.inkBlack,
    marginBottom: 10,
  },
  tierCard: {
    borderRadius: 6,
    ...Borders.thick,
    padding: 14,
    marginBottom: 12,
  },
  tierCardSelected: {
    backgroundColor: Colors.canvasTint,
    borderColor: Colors.inkBlack,
    borderWidth: 3,
  },
  tierCardUnselected: {
    backgroundColor: Colors.canvasBase,
  },
  tierHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  tierNameCol: {
    flex: 1,
  },
  tierBadgeRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  tierTitle: {
    ...Typography.titleMd,
    fontWeight: '800',
    color: Colors.inkBlack,
    marginRight: 6,
  },
  popularBadge: {
    backgroundColor: Colors.popVermilion,
    paddingVertical: 1,
    paddingHorizontal: 5,
    borderRadius: 3,
    ...Borders.hairline,
  },
  popularBadgeText: {
    ...Typography.labelSm,
    fontSize: 8,
    color: Colors.canvasBase,
  },
  tierAvailability: {
    ...Typography.labelSm,
    fontSize: 9,
    color: Colors.outline,
    marginTop: 2,
  },
  tierPrice: {
    ...Typography.headlineMd,
    fontSize: 22,
    fontWeight: '800',
    color: Colors.electricCobalt,
  },
  perksList: {
    gap: 4,
    borderTopWidth: 1,
    borderTopColor: Colors.surfaceDim,
    paddingTop: 8,
  },
  perkItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  perkCheck: {
    fontSize: 12,
    fontWeight: '800',
    color: Colors.electricCobalt,
    marginRight: 6,
  },
  perkText: {
    ...Typography.bodyMd,
    fontSize: 12,
    color: Colors.onSurfaceVariant,
  },
  quantityBox: {
    backgroundColor: Colors.canvasTint,
    borderRadius: 6,
    ...Borders.thick,
    padding: 14,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  quantityTitle: {
    ...Typography.labelLg,
    fontSize: 12,
    color: Colors.inkBlack,
  },
  quantitySub: {
    ...Typography.bodyMd,
    fontSize: 11,
    color: Colors.outline,
  },
  stepperRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  stepperButton: {
    width: 36,
    height: 36,
    borderRadius: 4,
    backgroundColor: Colors.canvasBase,
    ...Borders.thick,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepperButtonText: {
    fontSize: 18,
    fontWeight: '800',
    color: Colors.inkBlack,
  },
  quantityDisplay: {
    width: 36,
    alignItems: 'center',
  },
  quantityNumber: {
    ...Typography.headlineMd,
    fontSize: 18,
    fontWeight: '800',
    color: Colors.inkBlack,
  },
  stickyFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: Colors.canvasBase,
    borderTopWidth: 2.5,
    borderTopColor: Colors.inkBlack,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  footerPriceCol: {
    flex: 1,
    marginRight: 12,
  },
  footerTotalLabel: {
    ...Typography.labelSm,
    fontSize: 9,
    color: Colors.outline,
  },
  footerTotalPrice: {
    ...Typography.headlineMd,
    fontSize: 22,
    fontWeight: '800',
    color: Colors.inkBlack,
  },
  footerFeesLabel: {
    ...Typography.labelSm,
    fontSize: 8,
    color: Colors.outline,
  },
  footerCtaCol: {
    width: 170,
  },
});
