/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * ScanVerifyScreen (React Native & Expo)
 * AI Optical Scanner & Anti-Counterfeit Turnstile Validator.
 * Simulates high-speed optical camera scanning with corner brackets,
 * active laser sweep, and real-time cryptographic ticket verification.
 */

import React, { useState } from 'react';
import {
  View,
  Text,
  Pressable,
  StyleSheet,
} from 'react-native';
import { Colors } from '../theme/colors';
import { Typography } from '../theme/typography';
import { Shadows, Borders } from '../theme/shadows';
import { PopButton } from '../components/PopButton';

export interface ScanVerifyScreenProps {
  onBack: () => void;
  onTicketVerified: (ticketCode: string) => void;
}

export const ScanVerifyScreen: React.FC<ScanVerifyScreenProps> = ({
  onBack,
  onTicketVerified,
}) => {
  const [scanState, setScanState] = useState<'IDLE' | 'SCANNING' | 'SUCCESS'>('IDLE');
  const [lastScannedCode, setLastScannedCode] = useState<string>('');

  const triggerMockScan = (code: string) => {
    setScanState('SCANNING');
    setLastScannedCode(code);

    setTimeout(() => {
      setScanState('SUCCESS');
      onTicketVerified(code);
    }, 1200);
  };

  return (
    <View style={styles.screenRoot}>
      {/* Top Bar */}
      <View style={styles.appBar}>
        <Pressable
          onPress={onBack}
          style={({ pressed }) => [
            styles.backButton,
            pressed ? Shadows.pressed : Shadows.small,
          ]}
        >
          <Text style={styles.backButtonText}>← CLOSE</Text>
        </Pressable>

        <Text style={styles.headerTitle}>AI TURNSTILE SCAN</Text>

        <View style={styles.onlinePill}>
          <View style={styles.onlineDot} />
          <Text style={styles.onlineText}>LIVE</Text>
        </View>
      </View>

      {/* Main Viewfinder Section */}
      <View style={styles.viewfinderContainer}>
        <Text style={styles.viewfinderInstructions}>
          ALIGN PHYSICAL TICKET QR INSIDE COMIC RETICLE
        </Text>

        {/* Optical Frame */}
        <View style={[styles.reticleFrame, Shadows.card]}>
          {/* Comic Corner Brackets */}
          <View style={[styles.bracket, styles.bracketTopLeft]} />
          <View style={[styles.bracket, styles.bracketTopRight]} />
          <View style={[styles.bracket, styles.bracketBottomLeft]} />
          <View style={[styles.bracket, styles.bracketBottomRight]} />

          {/* Halftone / Ben-Day Dot Pattern Texture */}
          <View style={styles.halftoneScreen}>
            <Text style={styles.scannerWatermark}>AI TICKET IT</Text>
            <Text style={styles.scannerSubmark}>CRYPTOGRAPHIC SCANNER</Text>

            {scanState === 'SCANNING' && (
              <View style={styles.laserSweepBar}>
                <View style={styles.laserGlow} />
              </View>
            )}

            {scanState === 'SUCCESS' && (
              <View style={styles.successStamp}>
                <Text style={styles.successStampIcon}>✓</Text>
                <Text style={styles.successStampText}>VALID PASS</Text>
                <Text style={styles.successStampCode}>{lastScannedCode}</Text>
              </View>
            )}
          </View>
        </View>

        {/* Validation Console Panel */}
        <View style={[styles.consolePanel, Shadows.card]}>
          <View style={styles.consoleHeader}>
            <Text style={styles.consoleTitle}>ANTI-COUNTERFEIT ENGINE</Text>
            <View style={styles.consoleBadge}>
              <Text style={styles.consoleBadgeText}>AI SECURE v3.2</Text>
            </View>
          </View>

          <Text style={styles.consoleStatus}>
            {scanState === 'IDLE' && 'STATUS: Waiting for optical barcode / QR stream...'}
            {scanState === 'SCANNING' && 'STATUS: De-hashing RSA signature and checking turnstile database...'}
            {scanState === 'SUCCESS' && 'STATUS: PASS AUTHENTICATED! Gate B unlocked for entry.'}
          </Text>

          {/* Quick Mock Barcode Buttons for User Testing */}
          <View style={styles.sampleTriggers}>
            <Text style={styles.samplePrompt}>TAP TO TEST RECOGNITION:</Text>
            <View style={styles.sampleRow}>
              <PopButton
                label="SCAN TICKET #1"
                onPress={() => triggerMockScan('TK-POP-88219')}
                variant="yellow"
                size="sm"
              />
              <PopButton
                label="SCAN TICKET #2"
                onPress={() => triggerMockScan('TK-POP-90412')}
                variant="primary"
                size="sm"
              />
            </View>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  screenRoot: {
    flex: 1,
    backgroundColor: Colors.canvasBase,
  },
  appBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: Colors.canvasBase,
    borderBottomWidth: 2.5,
    borderBottomColor: Colors.inkBlack,
  },
  backButton: {
    backgroundColor: Colors.canvasTint,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 4,
    ...Borders.thick,
  },
  backButtonText: {
    ...Typography.labelSm,
    fontWeight: '800',
    color: Colors.inkBlack,
  },
  headerTitle: {
    ...Typography.titleMd,
    fontWeight: '800',
    color: Colors.inkBlack,
  },
  onlinePill: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.successLight,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 9999,
    ...Borders.hairline,
  },
  onlineDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: Colors.success,
    marginRight: 4,
  },
  onlineText: {
    ...Typography.labelSm,
    fontSize: 9,
    color: Colors.inkBlack,
  },
  viewfinderContainer: {
    flex: 1,
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  viewfinderInstructions: {
    ...Typography.labelLg,
    fontSize: 11,
    color: Colors.inkBlack,
    textAlign: 'center',
    marginBottom: 20,
    letterSpacing: 0.6,
  },
  reticleFrame: {
    width: 260,
    height: 260,
    backgroundColor: Colors.canvasTint,
    borderRadius: 8,
    ...Borders.thick,
    position: 'relative',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 24,
  },
  bracket: {
    position: 'absolute',
    width: 24,
    height: 24,
    borderColor: Colors.electricCobalt,
  },
  bracketTopLeft: {
    top: -3,
    left: -3,
    borderTopWidth: 4,
    borderLeftWidth: 4,
  },
  bracketTopRight: {
    top: -3,
    right: -3,
    borderTopWidth: 4,
    borderRightWidth: 4,
  },
  bracketBottomLeft: {
    bottom: -3,
    left: -3,
    borderBottomWidth: 4,
    borderLeftWidth: 4,
  },
  bracketBottomRight: {
    bottom: -3,
    right: -3,
    borderBottomWidth: 4,
    borderRightWidth: 4,
  },
  halftoneScreen: {
    width: 220,
    height: 220,
    backgroundColor: Colors.surfaceDim,
    borderRadius: 4,
    ...Borders.standard,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
    overflow: 'hidden',
  },
  scannerWatermark: {
    ...Typography.headlineMd,
    fontSize: 16,
    color: Colors.outline,
    letterSpacing: 1.5,
  },
  scannerSubmark: {
    ...Typography.labelSm,
    fontSize: 8,
    color: Colors.outline,
    marginTop: 4,
  },
  laserSweepBar: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: '50%',
    height: 4,
    backgroundColor: Colors.popVermilion,
    zIndex: 10,
  },
  laserGlow: {
    height: 12,
    marginTop: -4,
    backgroundColor: 'rgba(244, 63, 94, 0.4)',
  },
  successStamp: {
    position: 'absolute',
    inset: 10,
    backgroundColor: Colors.canaryYellow,
    borderRadius: 6,
    ...Borders.thick,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 20,
  },
  successStampIcon: {
    fontSize: 40,
    color: Colors.inkBlack,
    fontWeight: '900',
  },
  successStampText: {
    ...Typography.headlineMd,
    fontSize: 18,
    fontWeight: '900',
    color: Colors.inkBlack,
    marginTop: 4,
  },
  successStampCode: {
    ...Typography.labelLg,
    fontSize: 12,
    color: Colors.electricCobalt,
    marginTop: 2,
  },
  consolePanel: {
    width: '100%',
    backgroundColor: Colors.canvasTint,
    borderRadius: 6,
    ...Borders.thick,
    padding: 14,
  },
  consoleHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  consoleTitle: {
    ...Typography.labelSm,
    fontSize: 10,
    color: Colors.inkBlack,
  },
  consoleBadge: {
    backgroundColor: Colors.canaryYellow,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 3,
    ...Borders.hairline,
  },
  consoleBadgeText: {
    ...Typography.labelSm,
    fontSize: 8,
    fontWeight: '800',
    color: Colors.inkBlack,
  },
  consoleStatus: {
    ...Typography.bodyMd,
    fontSize: 12,
    color: Colors.inkBlack,
    marginBottom: 12,
  },
  sampleTriggers: {
    borderTopWidth: 1,
    borderTopColor: Colors.surfaceDim,
    paddingTop: 10,
  },
  samplePrompt: {
    ...Typography.labelSm,
    fontSize: 9,
    color: Colors.outline,
    marginBottom: 8,
  },
  sampleRow: {
    flexDirection: 'row',
    gap: 10,
  },
});
