/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * MyTicketsScreen (React Native & Expo)
 * Physical Ticket Wallet displaying interactive perforated ticket stubs,
 * high-contrast optical QR codes, and cryptographic AI anti-fraud stamps.
 */

import React, { useState } from 'react';
import {
  View,
  Text,
  FlatList,
  Pressable,
  Alert,
  StyleSheet,
} from 'react-native';
import { Colors } from '../theme/colors';
import { Typography } from '../theme/typography';
import { Shadows, Borders } from '../theme/shadows';
import { UserTicket } from '../types/ticket';
import { TicketStub } from '../components/TicketStub';

export interface MyTicketsScreenProps {
  tickets: UserTicket[];
  onScanPress?: () => void;
  onExplorePress?: () => void;
}

export const MyTicketsScreen: React.FC<MyTicketsScreenProps> = ({
  tickets,
  onScanPress,
  onExplorePress,
}) => {
  const [activeTab, setActiveTab] = useState<'ACTIVE' | 'PAST'>('ACTIVE');

  const displayedTickets = tickets.filter((t) =>
    activeTab === 'ACTIVE' ? t.status === 'ACTIVE' : t.status !== 'ACTIVE'
  );

  const handleAddToWallet = (ticket: UserTicket) => {
    Alert.alert(
      'PASS SYNCED TO WALLET',
      `Ticket #${ticket.ticketCode} for ${ticket.eventTitle} is now ready in Apple Wallet / Google Pay.`
    );
  };

  return (
    <View style={styles.screenRoot}>
      {/* Top Header */}
      <View style={styles.appBar}>
        <View>
          <Text style={styles.headerTitle}>MY TICKETS</Text>
          <Text style={styles.headerSubtitle}>
            PHYSICAL STUB VAULT · {tickets.length} TOTAL
          </Text>
        </View>

        {onScanPress && (
          <Pressable
            onPress={onScanPress}
            style={({ pressed }) => [
              styles.scannerButton,
              pressed ? Shadows.pressed : Shadows.interactive,
            ]}
          >
            <Text style={styles.scannerIcon}>📷</Text>
            <Text style={styles.scannerLabel}>SCANNER</Text>
          </Pressable>
        )}
      </View>

      {/* Segmented Control Tabs */}
      <View style={styles.tabBar}>
        <Pressable
          onPress={() => setActiveTab('ACTIVE')}
          style={[
            styles.tabItem,
            activeTab === 'ACTIVE' && styles.tabItemActive,
          ]}
        >
          <Text
            style={[
              styles.tabText,
              activeTab === 'ACTIVE' && styles.tabTextActive,
            ]}
          >
            ACTIVE PASSES ({tickets.filter((t) => t.status === 'ACTIVE').length})
          </Text>
        </Pressable>

        <Pressable
          onPress={() => setActiveTab('PAST')}
          style={[
            styles.tabItem,
            activeTab === 'PAST' && styles.tabItemActive,
          ]}
        >
          <Text
            style={[
              styles.tabText,
              activeTab === 'PAST' && styles.tabTextActive,
            ]}
          >
            PAST MEMORIES (0)
          </Text>
        </Pressable>
      </View>

      {/* Ticket List */}
      <FlatList
        data={displayedTickets}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.listContainer}
        ListHeaderComponent={
          activeTab === 'ACTIVE' && displayedTickets.length > 0 ? (
            <View style={[styles.aiTurnstileTip, Shadows.small]}>
              <Text style={styles.tipIcon}>💡</Text>
              <Text style={styles.tipText}>
                Turn screen brightness to max at the gate. The AI optic contrast is calibrated for fast turnstile check-in.
              </Text>
            </View>
          ) : null
        }
        renderItem={({ item }) => (
          <TicketStub
            ticket={item}
            onAddToWallet={() => handleAddToWallet(item)}
            onPressQR={() => {
              Alert.alert(
                'TICKET AUTHENTICATED',
                `Code: ${item.ticketCode}\nHash: ${item.securityHash}\nValid for entry at ${item.gateInfo}.`
              );
            }}
          />
        )}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyIcon}>🎟️</Text>
            <Text style={styles.emptyTitle}>NO PASSES IN VAULT</Text>
            <Text style={styles.emptySubtitle}>
              You do not have any active concert or festival passes right now.
            </Text>

            {onExplorePress && (
              <Pressable
                onPress={onExplorePress}
                style={({ pressed }) => [
                  styles.exploreCta,
                  pressed ? Shadows.pressed : Shadows.interactive,
                ]}
              >
                <Text style={styles.exploreCtaText}>DISCOVER EVENTS</Text>
              </Pressable>
            )}
          </View>
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  screenRoot: {
    flex: 1,
    backgroundColor: Colors.canvasBase,
  },
  appBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 12,
    backgroundColor: Colors.canvasBase,
    borderBottomWidth: 2.5,
    borderBottomColor: Colors.inkBlack,
  },
  headerTitle: {
    ...Typography.headlineLg,
    fontSize: 22,
    lineHeight: 26,
    color: Colors.inkBlack,
  },
  headerSubtitle: {
    ...Typography.labelSm,
    fontSize: 9,
    color: Colors.outline,
    marginTop: 2,
  },
  scannerButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.canaryYellow,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 4,
    ...Borders.thick,
  },
  scannerIcon: {
    fontSize: 14,
    marginRight: 4,
  },
  scannerLabel: {
    ...Typography.labelSm,
    fontSize: 10,
    fontWeight: '800',
    color: Colors.inkBlack,
  },
  tabBar: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: Colors.canvasBase,
    gap: 8,
  },
  tabItem: {
    flex: 1,
    paddingVertical: 8,
    borderRadius: 4,
    ...Borders.standard,
    backgroundColor: Colors.canvasTint,
    alignItems: 'center',
  },
  tabItemActive: {
    backgroundColor: Colors.electricCobalt,
    borderColor: Colors.inkBlack,
  },
  tabText: {
    ...Typography.labelSm,
    fontSize: 10,
    fontWeight: '700',
    color: Colors.inkBlack,
  },
  tabTextActive: {
    color: Colors.canvasBase,
  },
  listContainer: {
    paddingHorizontal: 16,
    paddingBottom: 40,
  },
  aiTurnstileTip: {
    backgroundColor: Colors.cobaltLight,
    borderRadius: 4,
    ...Borders.hairline,
    padding: 10,
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 6,
    marginBottom: 8,
  },
  tipIcon: {
    fontSize: 16,
    marginRight: 8,
  },
  tipText: {
    ...Typography.bodyMd,
    fontSize: 11,
    color: Colors.cobaltDark,
    flex: 1,
  },
  emptyContainer: {
    padding: 40,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.canvasTint,
    borderRadius: 6,
    ...Borders.thick,
    marginTop: 40,
  },
  emptyIcon: {
    fontSize: 40,
    marginBottom: 10,
  },
  emptyTitle: {
    ...Typography.titleMd,
    fontWeight: '800',
    color: Colors.inkBlack,
  },
  emptySubtitle: {
    ...Typography.bodyMd,
    fontSize: 12,
    color: Colors.outline,
    textAlign: 'center',
    marginTop: 4,
    marginBottom: 16,
  },
  exploreCta: {
    backgroundColor: Colors.electricCobalt,
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 4,
    ...Borders.thick,
  },
  exploreCtaText: {
    ...Typography.labelMd,
    color: Colors.canvasBase,
    fontWeight: '800',
  },
});
