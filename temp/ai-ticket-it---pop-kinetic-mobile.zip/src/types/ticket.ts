/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * TypeScript definitions for AI Ticket It Pop Kinetic Mobile
 */

export type EventCategory = 'ALL' | 'CONCERTS' | 'FESTIVALS' | 'EXHIBITS' | 'INDIE' | 'TECH & AI';

export interface AIAnalysis {
  matchScore: number;          // e.g. 98%
  matchReason: string;         // "Matches your heavy synth & visual obsession"
  vibeTags: string[];          // ["High Kinetic", "130 BPM", "Immersive Audio"]
  crowdPrediction: 'Chill' | 'Electric' | 'Raving' | 'Curated';
  priceForecast: 'Best Price Now' | 'Likely to Rise' | 'Almost Sold Out';
  bestArrivalTime: string;     // e.g. "8:15 PM (Skips 25m gate line)"
  curatorNote: string;
}

export interface TicketTier {
  id: string;
  name: string;               // e.g. "GA Floor", "Lichtenstein VIP Box", "Early Bird Pass"
  price: number;
  availableCount: number;
  perks: string[];
  isPopular?: boolean;
}

export interface EventItem {
  id: string;
  title: string;
  subtitle: string;
  artist: string;
  date: string;
  time: string;
  venue: string;
  city: string;
  startingPrice: number;
  category: EventCategory;
  bannerImage: string;
  promoBadge?: 'AI PICK!' | 'VIP ACCESS' | 'HOT DEAL' | 'SELLING FAST' | 'NEW DROP';
  aiAnalysis: AIAnalysis;
  tiers: TicketTier[];
}

export interface UserTicket {
  id: string;
  ticketCode: string;          // e.g. "TK-POP-88219"
  eventId: string;
  eventTitle: string;
  artist: string;
  venue: string;
  date: string;
  time: string;
  tierName: string;
  seatInfo: string;           // "Row D · Seat 14"
  gateInfo: string;           // "Gate B · Fast Pass"
  qrCodeUrl: string;
  barcodeNumber: string;
  bannerImage: string;
  securityHash: string;
  status: 'ACTIVE' | 'USED' | 'TRANSFERRED';
  purchasedAt: string;
  aiVerifyStatus: 'CRYPTOGRAPHIC_VERIFIED' | 'PENDING' | 'INVALID';
}
