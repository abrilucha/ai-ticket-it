/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * React Native & Expo Primitive Runtime Implementation
 * Provides high-fidelity native primitives (<View>, <Text>, <Pressable>, <FlatList>,
 * <ScrollView>, <TextInput>, <Image>, <Modal>, <StyleSheet>, etc.)
 * allowing the code to be 100% compliant with React Native & Expo mobile environments
 * while executing seamlessly inside the AI Studio mobile preview framework.
 */

import React, { useState } from 'react';

// --- Type definitions conforming to React Native standard types ---
export type StyleProp<T> =
  | T
  | StyleProp<T>[]
  | undefined
  | null
  | false;

export interface ViewStyle {
  flex?: number;
  flexDirection?: 'row' | 'column' | 'row-reverse' | 'column-reverse';
  justifyContent?: 'flex-start' | 'flex-end' | 'center' | 'space-between' | 'space-around' | 'space-evenly';
  alignItems?: 'flex-start' | 'flex-end' | 'center' | 'stretch' | 'baseline';
  alignSelf?: 'auto' | 'flex-start' | 'flex-end' | 'center' | 'stretch' | 'baseline';
  flexWrap?: 'wrap' | 'nowrap' | 'wrap-reverse';
  backgroundColor?: string;
  width?: number | string;
  height?: number | string;
  minWidth?: number | string;
  maxWidth?: number | string;
  minHeight?: number | string;
  maxHeight?: number | string;
  padding?: number | string;
  paddingTop?: number | string;
  paddingBottom?: number | string;
  paddingLeft?: number | string;
  paddingRight?: number | string;
  paddingHorizontal?: number | string;
  paddingVertical?: number | string;
  margin?: number | string;
  marginTop?: number | string;
  marginBottom?: number | string;
  marginLeft?: number | string;
  marginRight?: number | string;
  marginHorizontal?: number | string;
  marginVertical?: number | string;
  borderWidth?: number;
  borderTopWidth?: number;
  borderBottomWidth?: number;
  borderLeftWidth?: number;
  borderRightWidth?: number;
  borderColor?: string;
  borderTopColor?: string;
  borderBottomColor?: string;
  borderLeftColor?: string;
  borderRightColor?: string;
  borderRadius?: number;
  borderTopLeftRadius?: number;
  borderTopRightRadius?: number;
  borderBottomLeftRadius?: number;
  borderBottomRightRadius?: number;
  borderStyle?: 'solid' | 'dotted' | 'dashed';
  position?: 'absolute' | 'relative';
  top?: number | string;
  bottom?: number | string;
  left?: number | string;
  right?: number | string;
  zIndex?: number;
  opacity?: number;
  overflow?: 'visible' | 'hidden' | 'scroll';
  transform?: Array<Record<string, any>>;
  shadowColor?: string;
  shadowOffset?: { width: number; height: number };
  shadowOpacity?: number;
  shadowRadius?: number;
  elevation?: number;
  boxShadow?: string;
  gap?: number;
  rowGap?: number;
  columnGap?: number;
}

export interface TextStyle extends ViewStyle {
  color?: string;
  fontFamily?: string;
  fontSize?: number;
  fontStyle?: 'normal' | 'italic';
  fontWeight?: 'normal' | 'bold' | '100' | '200' | '300' | '400' | '500' | '600' | '700' | '800' | '900';
  letterSpacing?: number;
  lineHeight?: number;
  textAlign?: 'auto' | 'left' | 'right' | 'center' | 'justify';
  textDecorationLine?: 'none' | 'underline' | 'line-through' | 'underline line-through';
  textTransform?: 'none' | 'uppercase' | 'lowercase' | 'capitalize';
}

export interface ImageStyle extends ViewStyle {
  resizeMode?: 'cover' | 'contain' | 'stretch' | 'repeat' | 'center';
  tintColor?: string;
}

// Convert RN styles (arrays, transforms, shadows) into flattened CSS style
function flattenRNStyle(style: any): React.CSSProperties {
  if (!style) return {};
  if (Array.isArray(style)) {
    return style.reduce((acc, curr) => ({ ...acc, ...flattenRNStyle(curr) }), {});
  }

  const css: Record<string, any> = { ...style };

  // Convert transform array e.g. [{ translateX: 3 }, { translateY: 3 }, { rotate: '5deg' }]
  if (Array.isArray(style.transform)) {
    const transformStr = style.transform
      .map((t: any) => {
        const [key, val] = Object.entries(t)[0] || [];
        if (!key) return '';
        if (typeof val === 'number') {
          if (key === 'rotate') return `${key}(${val}deg)`;
          return `${key}(${val}px)`;
        }
        return `${key}(${val})`;
      })
      .filter(Boolean)
      .join(' ');
    css.transform = transformStr;
  }

  // Convert RN shadow props to CSS boxShadow if not already specified
  if (!css.boxShadow && (css.shadowOffset || css.elevation)) {
    const ox = css.shadowOffset?.width ?? 0;
    const oy = css.shadowOffset?.height ?? 0;
    const rad = css.shadowRadius ?? 0;
    const col = css.shadowColor ?? '#000000';
    css.boxShadow = `${ox}px ${oy}px ${rad}px ${col}`;
  }

  return css as React.CSSProperties;
}

// --- React Native Primitives ---

export interface ViewProps {
  style?: StyleProp<ViewStyle>;
  children?: React.ReactNode;
  testID?: string;
  pointerEvents?: 'box-none' | 'none' | 'box-only' | 'auto';
  [key: string]: any;
}

export const View: React.FC<ViewProps> = ({ style, children, ...props }) => {
  return React.createElement(
    'div',
    {
      style: {
        display: 'flex',
        flexDirection: 'column',
        boxSizing: 'border-box',
        position: 'relative',
        ...flattenRNStyle(style),
      },
      ...props,
    },
    children
  );
};

export interface TextProps {
  style?: StyleProp<TextStyle>;
  children?: React.ReactNode;
  numberOfLines?: number;
  ellipsizeMode?: 'head' | 'middle' | 'tail' | 'clip';
  onPress?: () => void;
  [key: string]: any;
}

export const Text: React.FC<TextProps> = ({
  style,
  children,
  numberOfLines,
  onPress,
  ...props
}) => {
  const flattened = flattenRNStyle(style);
  const lineClampStyle: React.CSSProperties = numberOfLines
    ? {
        display: '-webkit-box',
        WebkitLineClamp: numberOfLines,
        WebkitBoxOrient: 'vertical',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
      }
    : {};

  return React.createElement(
    'span',
    {
      style: {
        boxSizing: 'border-box',
        ...flattened,
        ...lineClampStyle,
        cursor: onPress ? 'pointer' : 'inherit',
      },
      onClick: onPress,
      ...props,
    },
    children
  );
};

export interface PressableStateCallbackType {
  pressed: boolean;
}

export interface PressableProps {
  style?: StyleProp<ViewStyle> | ((state: PressableStateCallbackType) => StyleProp<ViewStyle>);
  children?: React.ReactNode | ((state: PressableStateCallbackType) => React.ReactNode);
  onPress?: () => void;
  onPressIn?: () => void;
  onPressOut?: () => void;
  disabled?: boolean;
  hitSlop?: number | { top?: number; bottom?: number; left?: number; right?: number };
  [key: string]: any;
}

export const Pressable: React.FC<PressableProps> = ({
  style,
  children,
  onPress,
  onPressIn,
  onPressOut,
  disabled,
  ...props
}) => {
  const [pressed, setPressed] = useState(false);

  const resolvedStyle = typeof style === 'function' ? style({ pressed }) : style;
  const resolvedChildren = typeof children === 'function' ? children({ pressed }) : children;

  return React.createElement(
    'div',
    {
      role: 'button',
      tabIndex: disabled ? -1 : 0,
      style: {
        display: 'flex',
        flexDirection: 'column',
        boxSizing: 'border-box',
        position: 'relative',
        cursor: disabled ? 'not-allowed' : 'pointer',
        userSelect: 'none',
        WebkitTapHighlightColor: 'transparent',
        ...flattenRNStyle(resolvedStyle),
      },
      onClick: (e: React.MouseEvent) => {
        if (!disabled && onPress) {
          e.stopPropagation();
          onPress();
        }
      },
      onMouseDown: () => {
        if (!disabled) {
          setPressed(true);
          onPressIn?.();
        }
      },
      onMouseUp: () => {
        if (!disabled) {
          setPressed(false);
          onPressOut?.();
        }
      },
      onMouseLeave: () => {
        if (!disabled && pressed) {
          setPressed(false);
          onPressOut?.();
        }
      },
      onTouchStart: () => {
        if (!disabled) {
          setPressed(true);
          onPressIn?.();
        }
      },
      onTouchEnd: () => {
        if (!disabled) {
          setPressed(false);
          onPressOut?.();
        }
      },
      ...props,
    },
    resolvedChildren
  );
};

export interface ScrollViewProps extends ViewProps {
  horizontal?: boolean;
  contentContainerStyle?: StyleProp<ViewStyle>;
  showsHorizontalScrollIndicator?: boolean;
  showsVerticalScrollIndicator?: boolean;
}

export const ScrollView: React.FC<ScrollViewProps> = ({
  style,
  horizontal,
  contentContainerStyle,
  showsHorizontalScrollIndicator = false,
  showsVerticalScrollIndicator = false,
  children,
  ...props
}) => {
  return React.createElement(
    'div',
    {
      style: {
        display: 'flex',
        flexDirection: horizontal ? 'row' : 'column',
        overflowX: horizontal ? 'auto' : 'hidden',
        overflowY: horizontal ? 'hidden' : 'auto',
        boxSizing: 'border-box',
        WebkitOverflowScrolling: 'touch',
        scrollbarWidth: showsVerticalScrollIndicator || showsHorizontalScrollIndicator ? 'auto' : 'none',
        msOverflowStyle: 'none',
        ...flattenRNStyle(style),
      },
      ...props,
    },
    React.createElement(
      'div',
      {
        style: {
          display: 'flex',
          flexDirection: horizontal ? 'row' : 'column',
          boxSizing: 'border-box',
          minWidth: horizontal ? 'max-content' : '100%',
          ...flattenRNStyle(contentContainerStyle),
        },
      },
      children
    )
  );
};

export interface FlatListProps<T> {
  data: readonly T[] | null | undefined;
  renderItem: (info: { item: T; index: number }) => React.ReactElement | null;
  keyExtractor?: (item: T, index: number) => string;
  horizontal?: boolean;
  contentContainerStyle?: StyleProp<ViewStyle>;
  style?: StyleProp<ViewStyle>;
  ItemSeparatorComponent?: React.ComponentType<any> | null;
  ListHeaderComponent?: React.ComponentType<any> | React.ReactElement | null;
  ListFooterComponent?: React.ComponentType<any> | React.ReactElement | null;
  ListEmptyComponent?: React.ComponentType<any> | React.ReactElement | null;
  numColumns?: number;
  showsHorizontalScrollIndicator?: boolean;
  showsVerticalScrollIndicator?: boolean;
}

export function FlatList<T>({
  data,
  renderItem,
  keyExtractor = (_, index) => String(index),
  horizontal = false,
  contentContainerStyle,
  style,
  ItemSeparatorComponent,
  ListHeaderComponent,
  ListFooterComponent,
  ListEmptyComponent,
  numColumns = 1,
  showsHorizontalScrollIndicator = false,
  showsVerticalScrollIndicator = false,
}: FlatListProps<T>) {
  if (!data || data.length === 0) {
    return React.createElement(
      'div',
      { style: { ...flattenRNStyle(style), ...flattenRNStyle(contentContainerStyle) } },
      ListHeaderComponent && (React.isValidElement(ListHeaderComponent) ? ListHeaderComponent : React.createElement(ListHeaderComponent)),
      ListEmptyComponent ? (React.isValidElement(ListEmptyComponent) ? ListEmptyComponent : React.createElement(ListEmptyComponent)) : null,
      ListFooterComponent && (React.isValidElement(ListFooterComponent) ? ListFooterComponent : React.createElement(ListFooterComponent))
    );
  }

  const items = data.map((item, index) => {
    const key = keyExtractor(item, index);
    const element = renderItem({ item, index });
    const isLast = index === data.length - 1;

    return React.createElement(
      React.Fragment,
      { key },
      element,
      !isLast && ItemSeparatorComponent ? React.createElement(ItemSeparatorComponent) : null
    );
  });

  return React.createElement(
    'div',
    {
      style: {
        display: 'flex',
        flexDirection: horizontal ? 'row' : 'column',
        overflowX: horizontal ? 'auto' : 'hidden',
        overflowY: horizontal ? 'hidden' : 'auto',
        boxSizing: 'border-box',
        WebkitOverflowScrolling: 'touch',
        scrollbarWidth: showsVerticalScrollIndicator || showsHorizontalScrollIndicator ? 'auto' : 'none',
        ...flattenRNStyle(style),
      },
    },
    React.createElement(
      'div',
      {
        style: {
          display: 'flex',
          flexDirection: horizontal ? 'row' : numColumns > 1 ? 'row' : 'column',
          flexWrap: numColumns > 1 ? 'wrap' : 'nowrap',
          boxSizing: 'border-box',
          minWidth: horizontal ? 'max-content' : '100%',
          ...flattenRNStyle(contentContainerStyle),
        },
      },
      ListHeaderComponent && (React.isValidElement(ListHeaderComponent) ? ListHeaderComponent : React.createElement(ListHeaderComponent)),
      items,
      ListFooterComponent && (React.isValidElement(ListFooterComponent) ? ListFooterComponent : React.createElement(ListFooterComponent))
    )
  );
}

export interface TextInputProps {
  value?: string;
  onChangeText?: (text: string) => void;
  placeholder?: string;
  placeholderTextColor?: string;
  style?: StyleProp<TextStyle>;
  secureTextEntry?: boolean;
  keyboardType?: 'default' | 'email-address' | 'numeric' | 'phone-pad' | 'url';
  multiline?: boolean;
  numberOfLines?: number;
  autoCapitalize?: 'none' | 'sentences' | 'words' | 'characters';
  autoCorrect?: boolean;
  editable?: boolean;
  onSubmitEditing?: () => void;
  returnKeyType?: 'done' | 'go' | 'next' | 'search' | 'send';
  [key: string]: any;
}

export const TextInput: React.FC<TextInputProps> = ({
  value,
  onChangeText,
  placeholder,
  placeholderTextColor,
  style,
  secureTextEntry,
  multiline,
  numberOfLines,
  editable = true,
  onSubmitEditing,
  ...props
}) => {
  const flattened = flattenRNStyle(style);
  const tag = multiline ? 'textarea' : 'input';

  return React.createElement(tag, {
    value: value ?? '',
    onChange: (e: any) => onChangeText?.(e.target.value),
    placeholder,
    disabled: !editable,
    rows: multiline ? numberOfLines || 3 : undefined,
    type: secureTextEntry ? 'password' : 'text',
    onKeyDown: (e: React.KeyboardEvent) => {
      if (e.key === 'Enter' && !multiline) {
        onSubmitEditing?.();
      }
    },
    style: {
      outline: 'none',
      border: 'none',
      backgroundColor: 'transparent',
      fontFamily: 'inherit',
      fontSize: 'inherit',
      boxSizing: 'border-box',
      ...flattened,
    },
    ...props,
  });
};

export interface ImageSourcePropType {
  uri?: string;
  [key: string]: any;
}

export interface ImageProps {
  source: ImageSourcePropType | string | number;
  style?: StyleProp<ImageStyle>;
  resizeMode?: 'cover' | 'contain' | 'stretch' | 'repeat' | 'center';
  alt?: string;
  [key: string]: any;
}

export const Image: React.FC<ImageProps> = ({
  source,
  style,
  resizeMode = 'cover',
  alt = 'image',
  ...props
}) => {
  const src = typeof source === 'string' ? source : (source as any)?.uri || '';
  const flattened = flattenRNStyle(style);

  return React.createElement('img', {
    src,
    alt,
    style: {
      objectFit: resizeMode,
      boxSizing: 'border-box',
      display: 'block',
      ...flattened,
    },
    ...props,
  });
};

export interface ModalProps {
  visible?: boolean;
  transparent?: boolean;
  animationType?: 'none' | 'slide' | 'fade';
  onRequestClose?: () => void;
  children?: React.ReactNode;
}

export const Modal: React.FC<ModalProps> = ({
  visible,
  onRequestClose,
  children,
}) => {
  if (!visible) return null;

  return React.createElement(
    'div',
    {
      style: {
        position: 'fixed',
        inset: 0,
        zIndex: 9999,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'rgba(10, 10, 10, 0.65)',
        backdropFilter: 'blur(2px)',
      },
      onClick: (e: React.MouseEvent) => {
        if (e.target === e.currentTarget) {
          onRequestClose?.();
        }
      },
    },
    children
  );
};

export const StatusBar: React.FC<{
  barStyle?: 'default' | 'light-content' | 'dark-content';
  backgroundColor?: string;
  hidden?: boolean;
}> = () => null;

export const Platform = {
  OS: 'ios' as 'ios' | 'android' | 'web',
  select: <T>(obj: { ios?: T; android?: T; default?: T }): T | undefined => {
    return obj.ios ?? obj.default;
  },
};

export const Dimensions = {
  get: (_type: 'window' | 'screen') => ({
    width: 393,
    height: 852,
    scale: 3,
    fontScale: 1,
  }),
};

export const Alert = {
  alert: (title: string, message?: string, buttons?: Array<{ text: string; onPress?: () => void }>) => {
    const confirmation = window.confirm(`${title}\n\n${message || ''}`);
    if (confirmation && buttons && buttons.length > 0) {
      buttons[buttons.length - 1]?.onPress?.();
    }
  },
};

export const StyleSheet = {
  create: <T extends Record<string, ViewStyle | TextStyle | ImageStyle>>(styles: T): T => {
    return styles;
  },
  flatten: flattenRNStyle,
  hairlineWidth: 1,
};
