/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * AIVibeModal Component (React Native & Expo)
 * Comic pop modal sheet breaking down AI Ticket It insights:
 * Acoustic profile, price prediction, queue timing, and curated seating tier.
 */

import React from 'react';
import {
  Modal,
  View,
  Text,
  Pressable,
  ScrollView,
  StyleSheet,
} from 'react-native';
import { Colors } from '../theme/colors';
import { Typography } from '../theme/typography';
import { Shadows, Borders } from '../theme/shadows';
import { EventItem } from '../types/ticket';
import { PopButton } from './PopButton';
import { StarburstBadge } from './StarburstBadge';

export interface AIVibeModalProps {
  visible: boolean;
  event: EventItem | null;
  onClose: () => void;
  onSelectTier: (tierId: string) => void;
}

export const AIVibeModal: React.FC<AIVibeModalProps> = ({
  visible,
  event,
  onClose,
  onSelectTier,
}) => {
  if (!event) return null;

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={[styles.dialogSheet, Shadows.modal]}>
          {/* Header Bar */}
          <View style={styles.modalHeader}>
            <View style={styles.headerTitleRow}>
              <Text style={styles.headerIcon}>⚡</Text>
              <Text style={styles.headerTitle}>AI TICKET INSIGHT</Text>
            </View>
            <Pressable
              onPress={onClose}
              style={({ pressed }) => [
                styles.closeButton,
                pressed && Shadows.pressed,
              ]}
            >
              <Text style={styles.closeButtonText}>✕</Text>
            </Pressable>
          </View>

          <ScrollView style={styles.modalScroll} showsVerticalScrollIndicator={false}>
            {/* Event Name & Starburst */}
            <View style={styles.eventBanner}>
              <View style={styles.eventTextSlot}>
                <Text style={styles.eventTitle}>{event.title}</Text>
                <Text style={styles.eventArtist}>{event.artist}</Text>
              </View>
              <StarburstBadge
                label={`${event.aiAnalysis.matchScore}% MATCH`}
                variant="yellow"
                rotation={-6}
              />
            </View>

            {/* AI Curator Note Box */}
            <View style={styles.curatorBox}>
              <Text style={styles.curatorLabel}>CURATOR AI VERDICT</Text>
              <Text style={styles.curatorQuote}>
                "{event.aiAnalysis.curatorNote}"
              </Text>
              <Text style={styles.matchReasonText}>
                💡 Why you will love it: {event.aiAnalysis.matchReason}
              </Text>
            </View>

            {/* Metric Grids */}
            <View style={styles.metricGrid}>
              <View style={styles.metricCard}>
                <Text style={styles.metricIcon}>📈</Text>
                <Text style={styles.metricLabel}>PRICE FORECAST</Text>
                <Text style={styles.metricValue}>{event.aiAnalysis.priceForecast}</Text>
              </View>

              <View style={styles.metricCard}>
                <Text style={styles.metricIcon}>🔥</Text>
                <Text style={styles.metricLabel}>CROWD ENERGY</Text>
                <Text style={styles.metricValue}>{event.aiAnalysis.crowdPrediction}</Text>
              </View>
            </View>

            {/* Queue & Arrival Intel */}
            <View style={styles.arrivalBox}>
              <Text style={styles.arrivalTitle}>OPTIMAL ARRIVAL TIME</Text>
              <Text style={styles.arrivalValue}>{event.aiAnalysis.bestArrivalTime}</Text>
              <Text style={styles.arrivalSubtitle}>
                Based on historic turnstile flow at {event.venue}.
              </Text>
            </View>

            {/* Vibe Tags */}
            <View style={styles.vibeTagsContainer}>
              <Text style={styles.tagsLabel}>DETECTED SOUND & VIBE PROFILE</Text>
              <View style={styles.tagsRow}>
                {event.aiAnalysis.vibeTags.map((tag, i) => (
                  <View key={i} style={styles.tagPill}>
                    <Text style={styles.tagPillText}>#{tag}</Text>
                  </View>
                ))}
              </View>
            </View>

            {/* Recommended Tier CTA */}
            <View style={styles.tierRecommendationBox}>
              <Text style={styles.recommendationHeader}>AI RECOMMENDED TIER</Text>
              <View style={styles.tierInfoRow}>
                <View>
                  <Text style={styles.recTierName}>{event.tiers[0]?.name}</Text>
                  <Text style={styles.recTierPerks}>
                    {event.tiers[0]?.perks.join(' · ')}
                  </Text>
                </View>
                <Text style={styles.recTierPrice}>${event.tiers[0]?.price}</Text>
              </View>

              <PopButton
                label={`SELECT ${event.tiers[0]?.name.toUpperCase()}`}
                onPress={() => {
                  onSelectTier(event.tiers[0]?.id || '');
                  onClose();
                }}
                variant="primary"
                size="md"
                fullWidth
              />
            </View>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(10, 10, 10, 0.65)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  dialogSheet: {
    width: '100%',
    maxWidth: 380,
    maxHeight: '85%',
    backgroundColor: Colors.canvasTint,
    borderRadius: 8,
    ...Borders.thick,
    overflow: 'hidden',
  },
  modalHeader: {
    backgroundColor: Colors.canaryYellow,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 2.5,
    borderBottomColor: Colors.inkBlack,
  },
  headerTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerIcon: {
    fontSize: 16,
    marginRight: 6,
  },
  headerTitle: {
    ...Typography.titleMd,
    fontWeight: '800',
    color: Colors.inkBlack,
    letterSpacing: 0.8,
  },
  closeButton: {
    width: 28,
    height: 28,
    borderRadius: 4,
    backgroundColor: Colors.canvasBase,
    ...Borders.hairline,
    alignItems: 'center',
    justifyContent: 'center',
  },
  closeButtonText: {
    fontSize: 14,
    fontWeight: '800',
    color: Colors.inkBlack,
  },
  modalScroll: {
    padding: 16,
  },
  eventBanner: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 14,
  },
  eventTextSlot: {
    flex: 1,
    marginRight: 12,
  },
  eventTitle: {
    ...Typography.headlineMd,
    fontSize: 18,
    lineHeight: 22,
    color: Colors.inkBlack,
  },
  eventArtist: {
    ...Typography.titleMd,
    fontSize: 13,
    color: Colors.popVermilion,
    marginTop: 2,
  },
  curatorBox: {
    backgroundColor: Colors.canvasBase,
    padding: 12,
    borderRadius: 4,
    ...Borders.standard,
    marginBottom: 12,
  },
  curatorLabel: {
    ...Typography.labelSm,
    fontSize: 9,
    color: Colors.electricCobalt,
    marginBottom: 4,
  },
  curatorQuote: {
    ...Typography.bodyMd,
    fontSize: 13,
    fontStyle: 'italic',
    color: Colors.inkBlack,
    marginBottom: 6,
  },
  matchReasonText: {
    ...Typography.bodyMd,
    fontSize: 12,
    color: Colors.onSurfaceVariant,
  },
  metricGrid: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 12,
  },
  metricCard: {
    flex: 1,
    backgroundColor: Colors.canvasBase,
    padding: 10,
    borderRadius: 4,
    ...Borders.standard,
  },
  metricIcon: {
    fontSize: 16,
    marginBottom: 4,
  },
  metricLabel: {
    ...Typography.labelSm,
    fontSize: 8,
    color: Colors.outline,
  },
  metricValue: {
    ...Typography.titleMd,
    fontSize: 13,
    fontWeight: '800',
    color: Colors.inkBlack,
    marginTop: 2,
  },
  arrivalBox: {
    backgroundColor: Colors.cobaltLight,
    padding: 12,
    borderRadius: 4,
    ...Borders.standard,
    marginBottom: 12,
  },
  arrivalTitle: {
    ...Typography.labelSm,
    fontSize: 9,
    color: Colors.cobaltDark,
    marginBottom: 2,
  },
  arrivalValue: {
    ...Typography.titleMd,
    fontSize: 14,
    fontWeight: '800',
    color: Colors.inkBlack,
  },
  arrivalSubtitle: {
    ...Typography.bodyMd,
    fontSize: 11,
    color: Colors.onSurfaceVariant,
    marginTop: 2,
  },
  vibeTagsContainer: {
    marginBottom: 16,
  },
  tagsLabel: {
    ...Typography.labelSm,
    fontSize: 9,
    color: Colors.outline,
    marginBottom: 6,
  },
  tagsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
  },
  tagPill: {
    backgroundColor: Colors.canaryYellow,
    paddingVertical: 3,
    paddingHorizontal: 8,
    borderRadius: 9999,
    ...Borders.hairline,
  },
  tagPillText: {
    ...Typography.labelSm,
    fontSize: 9,
    fontWeight: '700',
    color: Colors.inkBlack,
  },
  tierRecommendationBox: {
    backgroundColor: Colors.canvasBase,
    padding: 12,
    borderRadius: 6,
    ...Borders.thick,
    marginBottom: 16,
  },
  recommendationHeader: {
    ...Typography.labelSm,
    fontSize: 9,
    color: Colors.popVermilion,
    marginBottom: 6,
  },
  tierInfoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  recTierName: {
    ...Typography.titleMd,
    fontSize: 15,
    fontWeight: '800',
    color: Colors.inkBlack,
  },
  recTierPerks: {
    ...Typography.bodyMd,
    fontSize: 11,
    color: Colors.outline,
    marginTop: 2,
    maxWidth: 200,
  },
  recTierPrice: {
    ...Typography.headlineMd,
    fontSize: 20,
    fontWeight: '800',
    color: Colors.electricCobalt,
  },
});
