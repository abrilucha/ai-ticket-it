/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * StarburstBadge Component (React Native & Expo)
 * Comic-strip promotional starburst badge rotated at an expressive angle
 * with hard borders and Canary Yellow / Pop Vermilion punch ink.
 */

import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ViewStyle,
  StyleProp,
} from 'react-native';
import { Colors } from '../theme/colors';
import { Typography } from '../theme/typography';
import { Shadows, Borders } from '../theme/shadows';

export interface StarburstBadgeProps {
  label: string;
  variant?: 'yellow' | 'vermilion' | 'cobalt';
  rotation?: number;
  size?: 'sm' | 'md';
  style?: StyleProp<ViewStyle>;
}

export const StarburstBadge: React.FC<StarburstBadgeProps> = ({
  label,
  variant = 'yellow',
  rotation = -4,
  size = 'md',
  style,
}) => {
  const getBackgroundColor = () => {
    switch (variant) {
      case 'vermilion':
        return Colors.popVermilion;
      case 'cobalt':
        return Colors.electricCobalt;
      case 'yellow':
      default:
        return Colors.canaryYellow;
    }
  };

  const getTextColor = () => {
    return variant === 'yellow' ? Colors.inkBlack : Colors.canvasBase;
  };

  return (
    <View
      style={[
        styles.badgeContainer,
        {
          backgroundColor: getBackgroundColor(),
          transform: [{ rotate: `${rotation}deg` }],
        },
        size === 'sm' ? styles.smallPadding : styles.mediumPadding,
        Shadows.small,
        style,
      ]}
    >
      <View style={styles.innerGraphic}>
        <Text
          style={[
            styles.badgeText,
            { color: getTextColor() },
            size === 'sm' && styles.smallText,
          ]}
        >
          {label}
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  badgeContainer: {
    borderRadius: 4,
    ...Borders.thick,
    alignSelf: 'flex-start',
    zIndex: 10,
  },
  innerGraphic: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    alignItems: 'center',
    justifyContent: 'center',
  },
  mediumPadding: {
    padding: 2,
  },
  smallPadding: {
    padding: 1,
  },
  badgeText: {
    ...Typography.labelLg,
    fontSize: 11,
    letterSpacing: 0.8,
    fontWeight: '800',
  },
  smallText: {
    ...Typography.labelSm,
    fontSize: 9,
    letterSpacing: 0.5,
  },
});
