/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * PopButton Component (React Native & Expo)
 * Mid-century Pop Art mechanical button with 2.5px comic border,
 * hard offset drop shadow, and tactile compression on tap.
 */

import React from 'react';
import {
  Pressable,
  Text,
  View,
  StyleSheet,
  ViewStyle,
  TextStyle,
  StyleProp,
} from 'react-native';
import { Colors } from '../theme/colors';
import { Typography } from '../theme/typography';
import { Shadows, Borders } from '../theme/shadows';

export type PopButtonVariant = 'primary' | 'secondary' | 'accent' | 'outline' | 'yellow';
export type PopButtonSize = 'sm' | 'md' | 'lg';

export interface PopButtonProps {
  label: string;
  onPress: () => void;
  variant?: PopButtonVariant;
  size?: PopButtonSize;
  disabled?: boolean;
  icon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  labelStyle?: StyleProp<TextStyle>;
  fullWidth?: boolean;
}

export const PopButton: React.FC<PopButtonProps> = ({
  label,
  onPress,
  variant = 'primary',
  size = 'md',
  disabled = false,
  icon,
  rightIcon,
  style,
  labelStyle,
  fullWidth = false,
}) => {
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [
        styles.base,
        sizeStyles[size],
        variantStyles[variant],
        fullWidth && styles.fullWidth,
        pressed && !disabled ? Shadows.pressed : Shadows.interactive,
        disabled && styles.disabled,
        style,
      ]}
    >
      <View style={styles.contentRow}>
        {icon && <View style={styles.iconSlot}>{icon}</View>}
        <Text
          style={[
            styles.labelBase,
            sizeTextStyles[size],
            variantTextStyles[variant],
            disabled && styles.disabledLabel,
            labelStyle,
          ]}
        >
          {label}
        </Text>
        {rightIcon && <View style={styles.rightIconSlot}>{rightIcon}</View>}
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  base: {
    borderRadius: 4,
    ...Borders.thick,
    justifyContent: 'center',
    alignItems: 'center',
  },
  fullWidth: {
    width: '100%',
  },
  contentRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconSlot: {
    marginRight: 8,
  },
  rightIconSlot: {
    marginLeft: 8,
  },
  labelBase: {
    textAlign: 'center',
  },
  disabled: {
    opacity: 0.5,
    backgroundColor: Colors.surfaceDim,
  },
  disabledLabel: {
    color: Colors.outline,
  },
});

const sizeStyles = StyleSheet.create({
  sm: {
    paddingVertical: 6,
    paddingHorizontal: 12,
  },
  md: {
    paddingVertical: 10,
    paddingHorizontal: 16,
  },
  lg: {
    paddingVertical: 14,
    paddingHorizontal: 24,
  },
});

const sizeTextStyles = StyleSheet.create({
  sm: {
    ...Typography.labelSm,
  },
  md: {
    ...Typography.labelLg,
  },
  lg: {
    ...Typography.headlineMd,
    fontSize: 16,
    lineHeight: 20,
    letterSpacing: 0.5,
  },
});

const variantStyles = StyleSheet.create({
  primary: {
    backgroundColor: Colors.electricCobalt,
  },
  secondary: {
    backgroundColor: Colors.canvasTint,
  },
  accent: {
    backgroundColor: Colors.popVermilion,
  },
  outline: {
    backgroundColor: Colors.canvasBase,
  },
  yellow: {
    backgroundColor: Colors.canaryYellow,
  },
});

const variantTextStyles = StyleSheet.create({
  primary: {
    color: Colors.canvasBase,
  },
  secondary: {
    color: Colors.inkBlack,
  },
  accent: {
    color: Colors.canvasBase,
  },
  outline: {
    color: Colors.inkBlack,
  },
  yellow: {
    color: Colors.inkBlack,
  },
});
