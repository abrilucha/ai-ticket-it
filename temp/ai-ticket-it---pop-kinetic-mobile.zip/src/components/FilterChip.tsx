/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * FilterChip Component (React Native & Expo)
 * Pill-shaped capsule with 2px comic boundary, active yellow/cobalt pop state,
 * and tactile offset shadow.
 */

import React from 'react';
import {
  Pressable,
  Text,
  View,
  StyleSheet,
  ViewStyle,
  TextStyle,
  StyleProp,
} from 'react-native';
import { Colors } from '../theme/colors';
import { Typography } from '../theme/typography';
import { Shadows, Borders } from '../theme/shadows';

export interface FilterChipProps {
  label: string;
  selected: boolean;
  onPress: () => void;
  count?: number;
  icon?: React.ReactNode;
  activeColor?: 'yellow' | 'cobalt' | 'vermilion';
  style?: StyleProp<ViewStyle>;
}

export const FilterChip: React.FC<FilterChipProps> = ({
  label,
  selected,
  onPress,
  count,
  icon,
  activeColor = 'yellow',
  style,
}) => {
  const getActiveBackgroundColor = () => {
    switch (activeColor) {
      case 'cobalt':
        return Colors.electricCobalt;
      case 'vermilion':
        return Colors.popVermilion;
      case 'yellow':
      default:
        return Colors.canaryYellow;
    }
  };

  const getActiveTextColor = () => {
    return activeColor === 'cobalt' || activeColor === 'vermilion'
      ? Colors.canvasBase
      : Colors.inkBlack;
  };

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.chip,
        selected
          ? { backgroundColor: getActiveBackgroundColor() }
          : styles.unselectedChip,
        pressed ? Shadows.pressed : Shadows.small,
        style,
      ]}
    >
      <View style={styles.content}>
        {icon && <View style={styles.iconContainer}>{icon}</View>}
        <Text
          style={[
            styles.label,
            selected
              ? { color: getActiveTextColor(), fontWeight: '800' }
              : styles.unselectedLabel,
          ]}
        >
          {label}
        </Text>
        {count !== undefined && (
          <View
            style={[
              styles.countBadge,
              selected
                ? { backgroundColor: Colors.inkBlack }
                : { backgroundColor: Colors.surfaceDim },
            ]}
          >
            <Text
              style={[
                styles.countText,
                selected
                  ? { color: Colors.canvasBase }
                  : { color: Colors.inkBlack },
              ]}
            >
              {count}
            </Text>
          </View>
        )}
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  chip: {
    borderRadius: 9999,
    ...Borders.standard,
    paddingVertical: 6,
    paddingHorizontal: 14,
    marginRight: 8,
    alignSelf: 'flex-start',
  },
  unselectedChip: {
    backgroundColor: Colors.canvasBase,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconContainer: {
    marginRight: 6,
  },
  label: {
    ...Typography.labelMd,
  },
  unselectedLabel: {
    color: Colors.inkBlack,
  },
  countBadge: {
    marginLeft: 6,
    paddingHorizontal: 6,
    paddingVertical: 1,
    borderRadius: 9999,
  },
  countText: {
    ...Typography.labelSm,
    fontSize: 9,
  },
});
