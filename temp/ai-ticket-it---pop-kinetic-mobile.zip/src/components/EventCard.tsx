/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * EventCard Component (React Native & Expo)
 * Pop Art comic panel event card featuring Lichtenstein offset drop shadows,
 * AI match affinity score, sharp image boundary, and tactile press mechanics.
 */

import React from 'react';
import {
  View,
  Text,
  Image,
  Pressable,
  StyleSheet,
  ViewStyle,
  StyleProp,
} from 'react-native';
import { Colors } from '../theme/colors';
import { Typography } from '../theme/typography';
import { Shadows, Borders } from '../theme/shadows';
import { EventItem } from '../types/ticket';
import { StarburstBadge } from './StarburstBadge';

export interface EventCardProps {
  event: EventItem;
  onPress: () => void;
  onVibeCheckPress?: () => void;
  style?: StyleProp<ViewStyle>;
  featured?: boolean;
}

export const EventCard: React.FC<EventCardProps> = ({
  event,
  onPress,
  onVibeCheckPress,
  style,
  featured = false,
}) => {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.cardContainer,
        featured ? styles.featuredCard : styles.regularCard,
        pressed ? Shadows.pressed : Shadows.card,
        style,
      ]}
    >
      {/* Visual Header / Poster */}
      <View style={styles.imageWrapper}>
        <Image
          source={{ uri: event.bannerImage }}
          style={featured ? styles.featuredImage : styles.regularImage}
          resizeMode="cover"
        />

        {/* Promo Starburst Stamp */}
        {event.promoBadge && (
          <View style={styles.starburstSlot}>
            <StarburstBadge
              label={event.promoBadge}
              variant={event.promoBadge === 'HOT DEAL' ? 'vermilion' : 'yellow'}
              rotation={-5}
              size="sm"
            />
          </View>
        )}

        {/* AI Match Chip */}
        <View style={styles.aiMatchBadge}>
          <Text style={styles.aiMatchIcon}>⚡</Text>
          <Text style={styles.aiMatchText}>{event.aiAnalysis.matchScore}% MATCH</Text>
        </View>

        {/* Price Tag Graphic */}
        <View style={styles.priceTag}>
          <Text style={styles.priceCurrency}>FROM</Text>
          <Text style={styles.priceValue}>${event.startingPrice}</Text>
        </View>
      </View>

      {/* Card Content Panel */}
      <View style={styles.contentBody}>
        {/* Date & Category Ticker */}
        <View style={styles.metaRow}>
          <View style={styles.categoryBadge}>
            <Text style={styles.categoryText}>{event.category}</Text>
          </View>
          <Text style={styles.dateTimeText}>
            {event.date} · {event.time}
          </Text>
        </View>

        {/* Event Title & Subtitle */}
        <Text style={styles.eventTitle} numberOfLines={2}>
          {event.title}
        </Text>
        <Text style={styles.artistName} numberOfLines={1}>
          {event.artist}
        </Text>

        {/* Venue Location */}
        <View style={styles.venueRow}>
          <Text style={styles.venueIcon}>📍</Text>
          <Text style={styles.venueText} numberOfLines={1}>
            {event.venue}, {event.city}
          </Text>
        </View>

        {/* AI Vibe Snippet & Interactive Pill */}
        <View style={styles.aiSnippetContainer}>
          <View style={styles.vibeTagsRow}>
            {event.aiAnalysis.vibeTags.slice(0, 2).map((tag, idx) => (
              <View key={idx} style={styles.vibeTag}>
                <Text style={styles.vibeTagText}>#{tag}</Text>
              </View>
            ))}
          </View>

          {onVibeCheckPress && (
            <Pressable
              onPress={() => onVibeCheckPress()}
              style={({ pressed }) => [
                styles.vibeCheckButton,
                pressed ? Shadows.pressed : Shadows.small,
              ]}
            >
              <Text style={styles.vibeCheckText}>✨ AI Vibe</Text>
            </Pressable>
          )}
        </View>
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  cardContainer: {
    backgroundColor: Colors.canvasTint,
    borderRadius: 4,
    ...Borders.thick,
    marginBottom: 16,
    overflow: 'hidden',
  },
  regularCard: {
    width: '100%',
  },
  featuredCard: {
    width: 290,
    marginRight: 16,
    marginBottom: 12,
  },
  imageWrapper: {
    position: 'relative',
    borderBottomWidth: 2.5,
    borderBottomColor: Colors.inkBlack,
    backgroundColor: Colors.surfaceDim,
  },
  regularImage: {
    width: '100%',
    height: 160,
  },
  featuredImage: {
    width: '100%',
    height: 175,
  },
  starburstSlot: {
    position: 'absolute',
    top: 10,
    left: 10,
  },
  aiMatchBadge: {
    position: 'absolute',
    top: 10,
    right: 10,
    backgroundColor: Colors.canaryYellow,
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 3,
    paddingHorizontal: 8,
    borderRadius: 9999,
    ...Borders.hairline,
    ...Shadows.small,
  },
  aiMatchIcon: {
    fontSize: 10,
    marginRight: 3,
  },
  aiMatchText: {
    ...Typography.labelSm,
    color: Colors.inkBlack,
    fontWeight: '800',
  },
  priceTag: {
    position: 'absolute',
    bottom: 10,
    right: 10,
    backgroundColor: Colors.electricCobalt,
    paddingVertical: 4,
    paddingHorizontal: 10,
    borderRadius: 4,
    ...Borders.hairline,
    ...Shadows.small,
    alignItems: 'center',
  },
  priceCurrency: {
    ...Typography.labelSm,
    fontSize: 8,
    color: Colors.canvasBase,
  },
  priceValue: {
    ...Typography.titleMd,
    fontSize: 15,
    fontWeight: '800',
    color: Colors.canvasBase,
  },
  contentBody: {
    padding: 14,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 6,
  },
  categoryBadge: {
    backgroundColor: Colors.surfaceDim,
    paddingVertical: 2,
    paddingHorizontal: 6,
    borderRadius: 2,
    ...Borders.hairline,
  },
  categoryText: {
    ...Typography.labelSm,
    fontSize: 9,
    color: Colors.inkBlack,
  },
  dateTimeText: {
    ...Typography.bodyMd,
    fontSize: 12,
    fontWeight: '600',
    color: Colors.onSurfaceVariant,
  },
  eventTitle: {
    ...Typography.headlineMd,
    fontSize: 18,
    lineHeight: 22,
    color: Colors.inkBlack,
    marginBottom: 2,
  },
  artistName: {
    ...Typography.titleMd,
    fontSize: 14,
    color: Colors.popVermilion,
    marginBottom: 8,
    fontWeight: '700',
  },
  venueRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  venueIcon: {
    fontSize: 12,
    marginRight: 4,
  },
  venueText: {
    ...Typography.bodyMd,
    fontSize: 12,
    color: Colors.outline,
    flex: 1,
  },
  aiSnippetContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: Colors.surfaceDim,
  },
  vibeTagsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 4,
    flex: 1,
  },
  vibeTag: {
    backgroundColor: Colors.canvasBase,
    paddingVertical: 2,
    paddingHorizontal: 6,
    borderRadius: 3,
    borderWidth: 1,
    borderColor: Colors.surfaceDim,
  },
  vibeTagText: {
    ...Typography.labelSm,
    fontSize: 9,
    color: Colors.onSurfaceVariant,
  },
  vibeCheckButton: {
    backgroundColor: Colors.canaryYellow,
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 4,
    ...Borders.hairline,
  },
  vibeCheckText: {
    ...Typography.labelSm,
    fontSize: 10,
    color: Colors.inkBlack,
  },
});
