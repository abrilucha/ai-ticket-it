/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * SearchBar Component (React Native & Expo)
 * Comic panel styled input with crisp #FFFDF0 canvas tint surface,
 * 2.5px jet-black boundary, tactile offset shadow, and AI prompt quick filter.
 */

import React, { useState } from 'react';
import {
  View,
  TextInput,
  Pressable,
  Text,
  StyleSheet,
  ViewStyle,
  StyleProp,
} from 'react-native';
import { Colors } from '../theme/colors';
import { Typography } from '../theme/typography';
import { Shadows, Borders } from '../theme/shadows';

export interface SearchBarProps {
  value: string;
  onChangeText: (text: string) => void;
  placeholder?: string;
  onClear?: () => void;
  onAISearchPress?: () => void;
  style?: StyleProp<ViewStyle>;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  value,
  onChangeText,
  placeholder = 'Search artists, venues, vibes...',
  onClear,
  onAISearchPress,
  style,
}) => {
  const [isFocused, setIsFocused] = useState(false);

  return (
    <View
      style={[
        styles.container,
        isFocused ? styles.focusedShadow : Shadows.interactive,
        style,
      ]}
    >
      {/* Comic Search Stamp Icon */}
      <View style={styles.searchStamp}>
        <Text style={styles.searchIconText}>🔍</Text>
      </View>

      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={Colors.outline}
        style={styles.input}
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
        returnKeyType="search"
      />

      {value.length > 0 && (
        <Pressable
          onPress={() => {
            onChangeText('');
            onClear?.();
          }}
          style={({ pressed }) => [
            styles.clearButton,
            pressed && styles.clearButtonPressed,
          ]}
        >
          <Text style={styles.clearButtonText}>✕</Text>
        </Pressable>
      )}

      {onAISearchPress && (
        <Pressable
          onPress={onAISearchPress}
          style={({ pressed }) => [
            styles.aiFilterButton,
            pressed ? Shadows.pressed : Shadows.small,
          ]}
        >
          <Text style={styles.aiFilterText}>✨ AI VIBE</Text>
        </Pressable>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.canvasTint,
    borderRadius: 4,
    ...Borders.thick,
    paddingHorizontal: 12,
    height: 48,
  },
  focusedShadow: {
    shadowColor: Colors.electricCobalt,
    shadowOffset: { width: 3, height: 3 },
    shadowOpacity: 1,
    shadowRadius: 0,
    elevation: 3,
    boxShadow: `3px 3px 0px ${Colors.electricCobalt}`,
  },
  searchStamp: {
    marginRight: 8,
  },
  searchIconText: {
    fontSize: 16,
  },
  input: {
    flex: 1,
    ...Typography.bodyMd,
    color: Colors.inkBlack,
    paddingVertical: 8,
  },
  clearButton: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: Colors.surfaceDim,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 6,
  },
  clearButtonPressed: {
    backgroundColor: Colors.outlineVariant,
  },
  clearButtonText: {
    fontSize: 12,
    fontWeight: '800',
    color: Colors.inkBlack,
  },
  aiFilterButton: {
    backgroundColor: Colors.canaryYellow,
    paddingVertical: 5,
    paddingHorizontal: 8,
    borderRadius: 4,
    ...Borders.hairline,
  },
  aiFilterText: {
    ...Typography.labelSm,
    fontSize: 10,
    color: Colors.inkBlack,
    fontWeight: '800',
  },
});
