/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * TicketStub Component (React Native & Expo)
 * Physical Ticket Stub faithful to the Stitch Pop Kinetic design system.
 * Features inward semi-circle punch cutouts, authentic perforated dashed tear line,
 * high-contrast optical QR container, and AI anti-counterfeit cryptographic barcode.
 */

import React, { useState } from 'react';
import {
  View,
  Text,
  Image,
  Pressable,
  StyleSheet,
  ViewStyle,
  StyleProp,
} from 'react-native';
import { Colors } from '../theme/colors';
import { Typography } from '../theme/typography';
import { Shadows, Borders } from '../theme/shadows';
import { UserTicket } from '../types/ticket';
import { PopButton } from './PopButton';

export interface TicketStubProps {
  ticket: UserTicket;
  onPressQR?: () => void;
  onAddToWallet?: () => void;
  style?: StyleProp<ViewStyle>;
  interactive?: boolean;
}

export const TicketStub: React.FC<TicketStubProps> = ({
  ticket,
  onPressQR,
  onAddToWallet,
  style,
  interactive = true,
}) => {
  const [isRevealed, setIsRevealed] = useState(false);

  return (
    <View style={[styles.stubContainer, Shadows.card, style]}>
      {/* Top Header Section: Event Poster & Info */}
      <View style={styles.topSection}>
        <View style={styles.headerGraphicRow}>
          <Image
            source={{ uri: ticket.bannerImage }}
            style={styles.thumbnail}
            resizeMode="cover"
          />

          <View style={styles.headerTextCol}>
            <View style={styles.badgeRow}>
              <View style={styles.tierPill}>
                <Text style={styles.tierPillText}>{ticket.tierName}</Text>
              </View>
              <View
                style={[
                  styles.statusPill,
                  ticket.status === 'ACTIVE'
                    ? { backgroundColor: Colors.canaryYellow }
                    : { backgroundColor: Colors.surfaceDim },
                ]}
              >
                <Text style={styles.statusPillText}>{ticket.status}</Text>
              </View>
            </View>

            <Text style={styles.eventTitle} numberOfLines={2}>
              {ticket.eventTitle}
            </Text>
            <Text style={styles.artistName} numberOfLines={1}>
              {ticket.artist}
            </Text>
          </View>
        </View>

        {/* Date, Time & Venue Block */}
        <View style={styles.detailGrid}>
          <View style={styles.gridCell}>
            <Text style={styles.gridLabel}>DATE</Text>
            <Text style={styles.gridValue}>{ticket.date}</Text>
          </View>
          <View style={styles.gridCell}>
            <Text style={styles.gridLabel}>TIME</Text>
            <Text style={styles.gridValue}>{ticket.time}</Text>
          </View>
          <View style={styles.gridCell}>
            <Text style={styles.gridLabel}>SEAT</Text>
            <Text style={styles.gridValueHighlight}>{ticket.seatInfo}</Text>
          </View>
          <View style={styles.gridCell}>
            <Text style={styles.gridLabel}>ENTRY</Text>
            <Text style={styles.gridValue}>{ticket.gateInfo}</Text>
          </View>
        </View>

        <View style={styles.venueBanner}>
          <Text style={styles.venueLabel}>VENUE:</Text>
          <Text style={styles.venueValue} numberOfLines={1}>
            {ticket.venue}
          </Text>
        </View>
      </View>

      {/* --- AUTHENTIC PERFORATION LINE WITH INWARD SEMI-CIRCLE PUNCH NOTCHES --- */}
      <View style={styles.perforationRow}>
        {/* Left Semi-Circle Cutout */}
        <View style={styles.cutoutLeft} />

        {/* Dashed Perforation Line */}
        <View style={styles.perforatedLine} />

        {/* Right Semi-Circle Cutout */}
        <View style={styles.cutoutRight} />
      </View>

      {/* Bottom Section: Scannable AI Barcodes & QR Box */}
      <View style={styles.bottomSection}>
        <View style={styles.scanHeader}>
          <Text style={styles.scanPromptText}>SHOW AT GATE TURNSTILE</Text>
          <View style={styles.aiVerifiedBadge}>
            <Text style={styles.aiVerifiedIcon}>🛡️</Text>
            <Text style={styles.aiVerifiedText}>AI CRYPTO-VERIFIED</Text>
          </View>
        </View>

        {/* Dedicated high-contrast ivory QR box with corner markers */}
        <Pressable
          onPress={() => {
            setIsRevealed(!isRevealed);
            onPressQR?.();
          }}
          style={({ pressed }) => [
            styles.qrContainerBox,
            pressed && Shadows.pressed,
          ]}
        >
          {/* Corner graphic markers for instantaneous optical scanner recognition */}
          <View style={[styles.cornerMarker, styles.cornerTopLeft]} />
          <View style={[styles.cornerMarker, styles.cornerTopRight]} />
          <View style={[styles.cornerMarker, styles.cornerBottomLeft]} />
          <View style={[styles.cornerMarker, styles.cornerBottomRight]} />

          <Image
            source={{ uri: ticket.qrCodeUrl }}
            style={styles.qrImage}
            resizeMode="contain"
          />

          <Text style={styles.tapToEnlarge}>
            {isRevealed ? 'TAP TO MINIMIZE' : 'TAP FOR FULLSCREEN BRIGHTNESS'}
          </Text>
        </Pressable>

        {/* Barcode & Security Hash Ticker */}
        <View style={styles.barcodeSection}>
          {/* Stylized Barcode Graphic */}
          <View style={styles.simulatedBarcode}>
            {[1, 3, 2, 4, 1, 3, 5, 2, 1, 4, 2, 3, 1, 5, 2, 4, 1, 3, 2, 4, 1, 3, 2].map(
              (weight, i) => (
                <View
                  key={i}
                  style={[
                    styles.barcodeBar,
                    {
                      width: weight,
                      backgroundColor: i % 7 === 0 ? Colors.electricCobalt : Colors.inkBlack,
                    },
                  ]}
                />
              )
            )}
          </View>
          <Text style={styles.barcodeText}>{ticket.barcodeNumber}</Text>
          <Text style={styles.securityHash}>HASH: {ticket.securityHash}</Text>
        </View>

        {/* Actions Row */}
        {interactive && onAddToWallet && (
          <View style={styles.actionRow}>
            <PopButton
              label="ADD TO APPLE / GOOGLE WALLET"
              onPress={onAddToWallet}
              variant="outline"
              size="sm"
              fullWidth
            />
          </View>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  stubContainer: {
    backgroundColor: Colors.canvasTint,
    borderRadius: 8,
    ...Borders.thick,
    overflow: 'hidden',
    marginVertical: 12,
  },
  topSection: {
    padding: 16,
    backgroundColor: Colors.canvasTint,
  },
  headerGraphicRow: {
    flexDirection: 'row',
    marginBottom: 14,
  },
  thumbnail: {
    width: 72,
    height: 72,
    borderRadius: 4,
    ...Borders.standard,
    marginRight: 12,
  },
  headerTextCol: {
    flex: 1,
    justifyContent: 'center',
  },
  badgeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  tierPill: {
    backgroundColor: Colors.electricCobalt,
    paddingVertical: 2,
    paddingHorizontal: 6,
    borderRadius: 3,
    marginRight: 6,
    ...Borders.hairline,
  },
  tierPillText: {
    ...Typography.labelSm,
    fontSize: 9,
    color: Colors.canvasBase,
  },
  statusPill: {
    paddingVertical: 2,
    paddingHorizontal: 6,
    borderRadius: 3,
    ...Borders.hairline,
  },
  statusPillText: {
    ...Typography.labelSm,
    fontSize: 9,
    color: Colors.inkBlack,
  },
  eventTitle: {
    ...Typography.headlineMd,
    fontSize: 18,
    lineHeight: 22,
    color: Colors.inkBlack,
  },
  artistName: {
    ...Typography.titleMd,
    fontSize: 13,
    color: Colors.popVermilion,
    marginTop: 2,
  },
  detailGrid: {
    flexDirection: 'row',
    backgroundColor: Colors.canvasBase,
    borderRadius: 4,
    ...Borders.hairline,
    padding: 10,
    marginBottom: 10,
    justifyContent: 'space-between',
  },
  gridCell: {
    flex: 1,
    alignItems: 'center',
  },
  gridLabel: {
    ...Typography.labelSm,
    fontSize: 8,
    color: Colors.outline,
    marginBottom: 2,
  },
  gridValue: {
    ...Typography.titleMd,
    fontSize: 12,
    fontWeight: '700',
    color: Colors.inkBlack,
  },
  gridValueHighlight: {
    ...Typography.titleMd,
    fontSize: 12,
    fontWeight: '800',
    color: Colors.electricCobalt,
  },
  venueBanner: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  venueLabel: {
    ...Typography.labelSm,
    fontSize: 10,
    color: Colors.outline,
    marginRight: 4,
  },
  venueValue: {
    ...Typography.bodyMd,
    fontSize: 12,
    fontWeight: '600',
    color: Colors.inkBlack,
    flex: 1,
  },

  // Perforation & Inward Punch Notches
  perforationRow: {
    height: 24,
    backgroundColor: Colors.canvasTint,
    position: 'relative',
    justifyContent: 'center',
    alignItems: 'center',
  },
  perforatedLine: {
    width: '84%',
    borderTopWidth: 2,
    borderTopColor: Colors.inkBlack,
    borderStyle: 'dashed',
  },
  cutoutLeft: {
    position: 'absolute',
    left: -12,
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: Colors.canvasBase,
    ...Borders.thick,
    zIndex: 5,
  },
  cutoutRight: {
    position: 'absolute',
    right: -12,
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: Colors.canvasBase,
    ...Borders.thick,
    zIndex: 5,
  },

  // Bottom Scan Section
  bottomSection: {
    padding: 16,
    backgroundColor: Colors.canvasTint,
    alignItems: 'center',
  },
  scanHeader: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  scanPromptText: {
    ...Typography.labelSm,
    fontSize: 10,
    color: Colors.outline,
    letterSpacing: 0.8,
  },
  aiVerifiedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.successLight,
    paddingVertical: 2,
    paddingHorizontal: 6,
    borderRadius: 3,
    ...Borders.hairline,
  },
  aiVerifiedIcon: {
    fontSize: 10,
    marginRight: 4,
  },
  aiVerifiedText: {
    ...Typography.labelSm,
    fontSize: 9,
    color: Colors.inkBlack,
  },
  qrContainerBox: {
    backgroundColor: Colors.white,
    padding: 14,
    borderRadius: 6,
    ...Borders.thick,
    alignItems: 'center',
    position: 'relative',
    marginBottom: 12,
  },
  cornerMarker: {
    position: 'absolute',
    width: 10,
    height: 10,
    borderColor: Colors.inkBlack,
  },
  cornerTopLeft: {
    top: 4,
    left: 4,
    borderTopWidth: 2,
    borderLeftWidth: 2,
  },
  cornerTopRight: {
    top: 4,
    right: 4,
    borderTopWidth: 2,
    borderRightWidth: 2,
  },
  cornerBottomLeft: {
    bottom: 4,
    left: 4,
    borderBottomWidth: 2,
    borderLeftWidth: 2,
  },
  cornerBottomRight: {
    bottom: 4,
    right: 4,
    borderBottomWidth: 2,
    borderRightWidth: 2,
  },
  qrImage: {
    width: 140,
    height: 140,
  },
  tapToEnlarge: {
    ...Typography.labelSm,
    fontSize: 8,
    color: Colors.outline,
    marginTop: 6,
    textAlign: 'center',
  },
  barcodeSection: {
    alignItems: 'center',
    width: '100%',
    marginBottom: 12,
  },
  simulatedBarcode: {
    flexDirection: 'row',
    height: 36,
    alignItems: 'stretch',
    gap: 3,
    marginBottom: 4,
  },
  barcodeBar: {
    height: '100%',
    borderRadius: 1,
  },
  barcodeText: {
    ...Typography.titleLg,
    fontSize: 14,
    letterSpacing: 3,
    fontWeight: '800',
    color: Colors.inkBlack,
  },
  securityHash: {
    ...Typography.labelSm,
    fontSize: 8,
    color: Colors.outline,
    marginTop: 2,
  },
  actionRow: {
    width: '100%',
    marginTop: 4,
  },
});
